/**
 * AudioManager — Global Singleton
 * 
 * Reutiliza um único AudioContext para todo o app.
 * Evita lag, travamentos e o limite de ~6 AudioContexts simultâneos do Chrome.
 */

let _ctx = null;
let _initialized = false;

function getContext() {
  if (_ctx && _ctx.state !== 'closed') return _ctx;
  
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    _ctx = new AC();
  } catch {
    return null;
  }
  return _ctx;
}

/** Must be called from a user gesture (click/touch) to unlock audio */
export function initAudio() {
  if (_initialized) return;
  const ctx = getContext();
  if (ctx && ctx.state === 'suspended') {
    ctx.resume();
  }
  _initialized = true;
}

/** Resume if suspended (e.g. after tab switch) */
function ensureRunning() {
  const ctx = getContext();
  if (!ctx) return null;
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

/**
 * Play a synthesized tone. All params are optional with sane defaults.
 * @param {Object} opts
 * @param {'sine'|'square'|'triangle'|'sawtooth'} opts.type - Oscillator waveform
 * @param {number} opts.freq - Starting frequency in Hz
 * @param {number} opts.freqEnd - End frequency (ramp)
 * @param {number} opts.duration - Duration in seconds
 * @param {number} opts.volume - Peak gain (0–1)
 * @param {number} opts.delay - Delay before start in seconds
 * @param {'linear'|'exponential'} opts.ramp - Frequency ramp type
 */
export function playTone({
  type = 'sine',
  freq = 440,
  freqEnd = null,
  duration = 0.15,
  volume = 0.1,
  delay = 0,
  ramp = 'linear',
} = {}) {
  const ctx = ensureRunning();
  if (!ctx) return;

  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const t = ctx.currentTime + delay;
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);

    if (freqEnd !== null) {
      if (ramp === 'exponential') {
        osc.frequency.exponentialRampToValueAtTime(Math.max(freqEnd, 1), t + duration);
      } else {
        osc.frequency.linearRampToValueAtTime(freqEnd, t + duration);
      }
    }

    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(volume, t + 0.005); // Tiny attack to avoid click
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    osc.start(t);
    osc.stop(t + duration + 0.01);
  } catch {
    // Silently fail — audio is non-critical
  }
}

/**
 * Play multiple tones at once (chord/arpeggio).
 * @param {Array<Object>} tones - Array of playTone option objects
 */
export function playChord(tones) {
  tones.forEach(t => playTone(t));
}

// ─── Preset sound library ───────────────────────────────────────────

export function playSuccess() {
  playTone({ type: 'sine', freq: 800, freqEnd: 1200, duration: 0.15, volume: 0.15 });
  playTone({ type: 'sine', freq: 1200, freqEnd: 1600, duration: 0.2, volume: 0.1, delay: 0.1 });
}

export function playFail() {
  playTone({ type: 'sawtooth', freq: 150, freqEnd: 50, duration: 0.3, volume: 0.15 });
}

export function playTick() {
  playTone({ type: 'triangle', freq: 600, duration: 0.04, volume: 0.04 });
}

export function playSellSound() {
  playTone({ type: 'square', freq: 300, freqEnd: 800, duration: 0.1, volume: 0.08, ramp: 'linear' });
}

export function playWinSmall() {
  playTone({ type: 'sine', freq: 800, freqEnd: 1200, duration: 0.2, volume: 0.2, ramp: 'linear' });
}

export function playWinBig() {
  playTone({ type: 'square', freq: 600, duration: 0.15, volume: 0.15 });
  playTone({ type: 'square', freq: 800, duration: 0.15, volume: 0.15, delay: 0.1 });
  playTone({ type: 'square', freq: 1000, duration: 0.15, volume: 0.15, delay: 0.2 });
  playTone({ type: 'square', freq: 1200, duration: 0.3, volume: 0.15, delay: 0.3 });
}

export function playLose() {
  playTone({ type: 'sawtooth', freq: 200, freqEnd: 100, duration: 0.5, volume: 0.08, ramp: 'linear' });
}

export function playCrash() {
  playTone({ type: 'sawtooth', freq: 100, freqEnd: 30, duration: 0.5, volume: 0.2, ramp: 'linear' });
}

export function playCashout() {
  playTone({ type: 'square', freq: 800, freqEnd: 1200, duration: 0.2, volume: 0.12, ramp: 'linear' });
}

export function playCrashTick(multiplier = 1) {
  playTone({ type: 'sine', freq: 400 + (multiplier * 10), duration: 0.08, volume: 0.04 });
}

export function playHover() {
  playTone({ type: 'sine', freq: 800, duration: 0.04, volume: 0.015 });
}

export function playClick() {
  playTone({ type: 'triangle', freq: 1200, freqEnd: 200, duration: 0.1, volume: 0.04, ramp: 'exponential' });
}

// Farm sounds
export function playFarmSpin() {
  playTone({ type: 'square', freq: 400, freqEnd: 800, duration: 0.1, volume: 0.08, ramp: 'exponential' });
}

export function playFarmStop() {
  playTone({ type: 'triangle', freq: 600, freqEnd: 300, duration: 0.1, volume: 0.12, ramp: 'exponential' });
}

export function playFarmHold() {
  playTone({ type: 'sine', freq: 500, duration: 0.1, volume: 0.12 });
}

// CS Roulette win sound (synthesized differentiation per rarity)
export function playCSWinSynth(rarity) {
  const ctx = ensureRunning();
  if (!ctx) return;

  const t = (freq, type, timeOffset, dur, vol) => {
    playTone({ type, freq, duration: dur, volume: vol, delay: timeOffset });
  };

  switch (rarity) {
    case 'milspec':
      t(261.63, 'triangle', 0, 0.4, 0.08);
      break;
    case 'restricted':
      t(261.63, 'square', 0, 0.2, 0.08);
      t(329.63, 'square', 0.1, 0.4, 0.08);
      break;
    case 'classified':
      t(261.63, 'square', 0, 0.15, 0.08);
      t(329.63, 'square', 0.1, 0.15, 0.08);
      t(392.00, 'square', 0.2, 0.5, 0.1);
      break;
    case 'covert':
      t(261.63, 'sawtooth', 0, 0.1, 0.08);
      t(329.63, 'sawtooth', 0.1, 0.1, 0.08);
      t(392.00, 'sawtooth', 0.2, 0.1, 0.08);
      t(523.25, 'sawtooth', 0.3, 0.8, 0.12);
      break;
    case 'gold':
      t(392.00, 'sawtooth', 0, 1.5, 0.1);
      t(493.88, 'sawtooth', 0, 1.5, 0.1);
      t(587.33, 'sawtooth', 0, 1.5, 0.1);
      t(783.99, 'sawtooth', 0, 1.5, 0.1);
      break;
  }
}

// Auto-init on first user gesture
if (typeof window !== 'undefined') {
  const autoInit = () => {
    initAudio();
    window.removeEventListener('click', autoInit);
    window.removeEventListener('touchstart', autoInit);
    window.removeEventListener('keydown', autoInit);
  };
  window.addEventListener('click', autoInit, { once: true });
  window.addEventListener('touchstart', autoInit, { once: true });
  window.addEventListener('keydown', autoInit, { once: true });
}
