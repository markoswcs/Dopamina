import React, { useState, useEffect } from 'react';
import { Package, DollarSign } from 'lucide-react';
import { playSellSound } from '../audioManager';

export default function Inventory({ pixBalance, onUpdatePix }) {
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dopashop_inventory')) || []; } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem('dopashop_inventory', JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    const handleGiveItem = (e) => {
      const { item } = e.detail;
      setItems(prev => {
        const existing = prev.find(i => i.id === item.id);
        if (existing) {
          return prev.map(i => i.id === item.id ? { ...i, count: i.count + 1 } : i);
        }
        return [...prev, { ...item, count: 1 }];
      });
    };
    window.addEventListener('give_inventory_item', handleGiveItem);
    return () => window.removeEventListener('give_inventory_item', handleGiveItem);
  }, []);

  // playSellSound imported from audioManager

  const sellItem = (itemToSell) => {
    onUpdatePix(itemToSell.price);
    setItems(prev => {
      return prev.map(i => {
        if (i.id === itemToSell.id) {
          return { ...i, count: i.count - 1 };
        }
        return i;
      }).filter(i => i.count > 0);
    });
    playSellSound();
  };

  const sellAll = (itemToSell) => {
    const totalRevenue = itemToSell.price * itemToSell.count;
    onUpdatePix(totalRevenue);
    setItems(prev => prev.filter(i => i.id !== itemToSell.id));
    playSellSound();
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-zinc-500 bg-[#0A0A0B] rounded-[40px] max-w-sm mx-auto border-4 border-[#18181B] shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
        <Package className="w-16 h-16 mb-4 opacity-30" />
        <h3 className="text-xl font-bold text-zinc-400">Cofre Vazio</h3>
        <p className="text-sm text-center px-8 mt-2">Gire a Roleta Premium para ganhar relíquias e itens valiosos.</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-lg mx-auto bg-[#1a1a1a] rounded-lg overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] border-2 border-[#333] relative p-4">
      <div className="flex items-center justify-between mb-4 border-b border-[#333] pb-2">
        <h2 className="text-xl font-display font-black text-zinc-200 flex items-center gap-2">
          INVENTÁRIO
        </h2>
        <div className="bg-[#2a2a2a] px-3 py-1 rounded text-xs font-bold text-zinc-400 border border-[#444]">
          {items.reduce((acc, curr) => acc + curr.count, 0)} ITENS
        </div>
      </div>
      
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[500px] overflow-y-auto no-scrollbar pb-10">
        {items.map(item => (
          <div key={item.id} className={`relative bg-[#2a2a2a] aspect-square flex flex-col justify-between items-center group overflow-hidden border border-[#111] shadow-[inset_0_0_15px_rgba(0,0,0,0.5)] border-b-[6px] ${item.colorBorder}`}>
            
            {/* Rarity Background Glow */}
            <div className={`absolute inset-0 opacity-[0.05] bg-current blur-md pointer-events-none ${item.colorText}`}></div>
            
            <div className="absolute top-1 left-1 bg-black/60 px-1.5 py-0.5 rounded text-[9px] font-black text-emerald-400 border border-white/5 z-10 shadow-sm">
              R$ {item.price.toLocaleString('pt-BR')}
            </div>

            <div className="absolute top-1 right-1 bg-black/80 px-1.5 py-0.5 rounded text-[9px] font-black text-white border border-white/10 z-10 shadow-sm">
              x{item.count}
            </div>
            
            <div className="flex-1 flex items-center justify-center w-full">
              <span className="text-5xl relative z-10 drop-shadow-xl group-hover:scale-110 transition-transform">{item.icon}</span>
            </div>
            
            <div className="relative z-10 w-full text-center pb-1 px-1">
              <h4 className={`font-bold text-[9px] uppercase tracking-wider leading-tight text-zinc-300 truncate`}>{item.name}</h4>
            </div>
            
            {/* Hover Sell Actions */}
            <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
              <button onClick={() => sellItem(item)} className="w-[80%] py-1.5 bg-[#333] hover:bg-emerald-600 text-white rounded text-[10px] font-bold uppercase transition-colors">
                Vender 1
              </button>
              {item.count > 1 && (
                <button onClick={() => sellAll(item)} className="w-[80%] py-1.5 bg-[#444] hover:bg-emerald-500 text-white rounded text-[10px] font-bold uppercase transition-colors">
                  Vender Todos
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
