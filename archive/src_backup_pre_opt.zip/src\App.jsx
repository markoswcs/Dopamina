import React, { useState, useEffect } from "react";
import {
  Sparkles, ShoppingBag, Search, Gift, Shield, Truck, Trash2,
  Flame, RotateCw, Tag, Map, User, Heart
} from "lucide-react";
import { products, categories, coupons, getAuraRank } from "./productsData";
import ProductCard from "./components/ProductCard";
import CouponScratcher from "./components/CouponScratcher";
import DiscountRoulette from "./components/DiscountRoulette";
import CategoryNav from "./components/CategoryNav";
import BottomNav from "./components/BottomNav";
import ReviewSection from "./components/ReviewSection";
import CheckoutModal from "./components/CheckoutModal";
import ParticleEffect from "./components/ParticleEffect";
import TopMarquee from "./components/TopMarquee";
import ThemeToggle from "./components/ThemeToggle";
import OrderTracking from "./components/OrderTracking";
import UserProfile from "./components/UserProfile";
import CreatorSupport from "./components/CreatorSupport";
import BannerCarousel from "./components/BannerCarousel";
import ProductDetailModal from "./components/ProductDetailModal";
import AuraRanksModal from "./components/AuraRanksModal";
import WinPopup from "./components/WinPopup";
import FarmGame from "./components/FarmGame";
import BetaClicker from "./components/BetaClicker";
import DopaBank from "./components/DopaBank";
import CrashGame from "./components/CrashGame";
import GachaBoxes from "./components/GachaBoxes";
import Inventory from "./components/Inventory";

export default function App() {
  const [isDark, setIsDark] = useState(() => {
    return localStorage.getItem("dopashop_theme") === "dark";
  });
  const [activeTab, setActiveTab] = useState("home");
  const [activeGameTab, setActiveGameTab] = useState("bank");
  const [headerDisplay, setHeaderDisplay] = useState('aura'); // 'aura' | 'pix'
  const [activeCategory, setActiveCategory] = useState("all");
  const [cart, setCart] = useState([]);
  const [activeDiscount, setActiveDiscount] = useState(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(products[0]);
  
  // New Modals
  const [productDetailOpen, setProductDetailOpen] = useState(null);
  const [auraRanksOpen, setAuraRanksOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);
  const [winPrize, setWinPrize] = useState(null);
  const [ageGateOpen, setAgeGateOpen] = useState(false);
  const [isAgeVerified, setIsAgeVerified] = useState(false);
  
  // Persistent State
  const [aura, setAura] = useState(() => {
    try { 
      const saved = JSON.parse(localStorage.getItem("dopashop_aura"));
      if (saved === null || saved === undefined) return 10000; // Novo jogador começa com 10.000 Aura
      return Math.max(0, Math.round(saved * 10) / 10);
    } catch { return 10000; }
  });
  const [userData, setUserData] = useState(() => {
    try { return JSON.parse(localStorage.getItem("dopashop_user")) || null; } catch { return null; }
  });
  const [orders, setOrders] = useState(() => {
    try { return JSON.parse(localStorage.getItem("dopashop_orders")) || []; } catch { return []; }
  });
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem("dopashop_favorites")) || []; } catch { return []; }
  });
  const [pixBalance, setPixBalance] = useState(() => {
    try { 
      const saved = JSON.parse(localStorage.getItem("dopashop_pix"));
      if (saved === null || saved === undefined) return 500; // Novo jogador começa com 500 PIX
      return saved;
    } catch { return 500; }
  });
  const [activeTheme, setActiveTheme] = useState(() => {
    try { return JSON.parse(localStorage.getItem("dopashop_theme_colors")) || null; } catch { return null; }
  });

  // Sync to localStorage
  useEffect(() => { localStorage.setItem("dopashop_theme", isDark ? "dark" : "light"); document.body.classList.toggle("dark", isDark); }, [isDark]);

  // Secret Cheat Code (Press F9 3 times quickly to get 1M Aura)
  useEffect(() => {
    let f9Count = 0;
    let lastPressTime = 0;
    
    const handleKeyDown = (e) => {
      if (e.key === "F9") {
        const now = Date.now();
        // If more than 2 seconds passed since last F9, reset count
        if (now - lastPressTime > 2000) {
          f9Count = 0;
        }
        
        f9Count++;
        lastPressTime = now;
        
        if (f9Count === 3) {
          setAura(prev => prev + 1000000);
          console.log("Modo Deus Ativado: +1.000.000 Aura");
          f9Count = 0; // reset
        }
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);
  useEffect(() => { localStorage.setItem("dopashop_aura", JSON.stringify(aura)); }, [aura]);
  useEffect(() => { localStorage.setItem("dopashop_user", JSON.stringify(userData)); }, [userData]);
  useEffect(() => { localStorage.setItem("dopashop_orders", JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem("dopashop_favorites", JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { localStorage.setItem("dopashop_pix", JSON.stringify(pixBalance)); }, [pixBalance]);
  useEffect(() => {
    localStorage.setItem("dopashop_theme_colors", JSON.stringify(activeTheme));
    if (activeTheme) {
      document.documentElement.style.setProperty('--color-accent', activeTheme.accent);
      document.documentElement.style.setProperty('--color-accent-dark', activeTheme.dark);
    } else {
      document.documentElement.style.removeProperty('--color-accent');
      document.documentElement.style.removeProperty('--color-accent-dark');
    }
  }, [activeTheme]);

  // Preload heavy/delayed images on mount
  useEffect(() => {
    // Reveal app smoothly to prevent FOUC (Flash of Unstyled Content) during Vite dev
    setTimeout(() => {
      const root = document.getElementById("root");
      if (root) root.style.opacity = "1";
    }, 150);

    const preloadImages = [
      "/qr_code_do_pix.webp",
      ...products.filter(p => p.category === "ilicitos").map(p => p.image)
    ];
    preloadImages.forEach(src => {
      const link = document.createElement("link");
      link.rel = "preload";
      link.as = "image";
      link.href = src;
      link.fetchPriority = "high";
      document.head.appendChild(link);
    });
  }, []);

  const addAura = (amount) => setAura(prev => Math.round((prev + amount) * 10) / 10);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2000);
  };

  const handleAddToCart = (product, e) => { 
    if (e) e.stopPropagation();
    setCart(prev => [...prev, product]); 
    addAura(50); 
    showToast(`Adicionado ao carrinho! +50 Aura ✨`);
  };
  
  const handleBuyNow = (product, e) => { 
    if (e) e.stopPropagation();
    setCart(prev => [...prev, product]); 
    addAura(100); 
    setCheckoutOpen(true); 
  };
  
  const handleToggleFavorite = (productId, e) => {
    if (e) e.stopPropagation();
    setFavorites(prev => prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]);
    if (window.triggerDopaParticles && e) window.triggerDopaParticles(e.clientX, e.clientY);
  };

  const handleRemoveFromCart = (index, e) => { if (e && window.triggerDopaParticles) window.triggerDopaParticles(e.clientX, e.clientY); setCart(prev => prev.filter((_, i) => i !== index)); };
  
  const handleCouponReveal = (code) => {
    const found = coupons.find(c => c.code === code);
    if (found) { 
      if (found.type === 'aura') {
        addAura(found.auraAmount);
      } else {
        setActiveDiscount(found);
        addAura(150);
      }
      setWinPrize(found);
    }
  };

  const handleOrderComplete = (orderData) => {
    setOrders(prev => [orderData, ...prev]);
    addAura(500); // Big aura boost for completing an order
  };

  const handleCategoryChange = (catId) => {
    if (catId === 'ilicitos' && !isAgeVerified) {
      setAgeGateOpen(true);
    } else {
      setActiveCategory(catId);
    }
  };

  let filteredProducts = products;
  
  if (activeTab === "favorites") {
    filteredProducts = products.filter(p => favorites.includes(p.id));
  } else {
    filteredProducts = products.filter(p => {
      const matchesCategory = activeCategory === "all" ? p.category !== "ilicitos" : p.category === activeCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }

  const subtotal = cart.reduce((acc, item) => acc + item.price, 0);
  const fmt = (v) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  const formatPix = (val) => {
    if (val >= 1e12) return (val / 1e12).toFixed(2) + 'T';
    if (val >= 1e9) return (val / 1e9).toFixed(2) + 'B';
    if (val >= 1e6) return (val / 1e6).toFixed(2) + 'M';
    return val.toLocaleString('pt-BR');
  };
  const currentCat = categories.find(c => c.id === activeCategory);
  
  const currentAura = getAuraRank(aura);

  return (
    <div className={`min-h-screen pb-20 md:pb-6 transition-colors duration-300 ${isDark ? "dark" : ""}`}>
      <ParticleEffect isDark={isDark} />
      <TopMarquee />

      {/* Floating Toast */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] bg-accent text-white px-4 py-2 rounded-full shadow-lg font-bold text-xs flex items-center gap-2 animate-fade-in-up">
          <Sparkles className="w-4 h-4" /> {toastMessage}
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 theme-card border-b theme-border z-30 px-4 py-3 shadow-sm">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
          <div onClick={(e) => { if (window.triggerDopaParticles) window.triggerDopaParticles(e.clientX, e.clientY); setActiveTab("home"); setActiveCategory("all"); }} className="flex items-center gap-2 cursor-pointer select-none group shrink-0">
            <div className="bg-accent p-1.5 rounded-lg flex items-center justify-center">
              <Flame className="w-5 h-5 text-white fill-white group-hover:scale-110 transition-transform" />
            </div>
            <span className="font-display font-extrabold text-base md:text-xl tracking-tight theme-text hidden sm:block">
              DOPA<span className="text-accent">SHOP</span>
            </span>
          </div>

          <div className="hidden md:flex items-center flex-1 max-w-sm lg:max-w-md theme-surface border theme-border rounded-full px-4 py-2">
            <Search className="w-4 h-4 theme-muted mr-2" />
            <input type="text" placeholder="Pesquisar..." value={searchQuery} onChange={(e) => { setActiveTab("home"); setSearchQuery(e.target.value); }} className="bg-transparent text-xs w-full focus:outline-none theme-text" />
          </div>

          <div className="flex items-center gap-2 md:gap-3">
            <div className="flex bg-black/5 dark:bg-white/5 rounded-full p-1 border theme-border">
                <ThemeToggle isDark={isDark} onToggle={() => setIsDark(!isDark)} />
                <button onClick={() => setAuraRanksOpen(true)} className="w-7 h-7 rounded-full flex items-center justify-center hover:bg-black/10 dark:hover:bg-white/10 transition-colors" title="Cores do Tema">
                   🎨
                </button>
            </div>

            {/* Aura / PIX Toggle */}
            <div className="theme-surface border theme-border py-1.5 px-3 rounded-xl flex items-center gap-2 shadow-sm min-w-[140px] cursor-pointer hover:border-accent/50 transition-colors relative">
              <span className="text-lg leading-none" title={currentAura.name} onClick={() => setAuraRanksOpen(true)}>{currentAura.emoji}</span>
              <div className="flex-1 text-right" onClick={() => setHeaderDisplay(prev => prev === 'aura' ? 'pix' : 'aura')}>
                {headerDisplay === 'aura' ? (
                  <>
                    <div className="text-[7px] theme-muted font-bold uppercase tracking-wider leading-none" style={{color: currentAura.color}}>{currentAura.name}</div>
                    <div className="text-xs font-display font-bold theme-text leading-none mt-0.5">{Number(aura).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} Aura</div>
                    <div className="w-full bg-black/10 dark:bg-white/10 h-1 rounded-full mt-1 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500" style={{width: `${currentAura.progress}%`, backgroundColor: currentAura.color}}></div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="text-[7px] font-bold uppercase tracking-wider leading-none text-emerald-500">Saldo PIX</div>
                    <div className="text-xs font-display font-bold text-emerald-500 leading-none mt-0.5">R$ {formatPix(pixBalance)}</div>
                  </>
                )}
              </div>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1.5">
              {[
                { id: "home", label: "Home", icon: null },
                { id: "dopagames", label: "DopaGames", icon: null },
                { id: "tracking", label: "Rastreio", icon: Map },
                { id: "profile", label: userData?.name ? userData.name.split(" ")[0] : "Perfil", icon: User },
                { id: "support", label: "Apoiar", icon: Heart },
                { id: "cart", label: `Carrinho (${cart.length})`, icon: ShoppingBag },
              ].map(tab => {
                const Icon = tab.icon;
                return (
                  <button key={tab.id} onClick={(e) => { if (window.triggerDopaParticles) window.triggerDopaParticles(e.clientX, e.clientY); setActiveTab(tab.id); }}
                    className={`flex items-center gap-1.5 py-1.5 px-3 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                      activeTab === tab.id ? "bg-accent text-white" : "theme-text-secondary hover:theme-text"
                    }`}>
                    {Icon && <Icon className="w-3.5 h-3.5" />}
                    {tab.label}
                  </button>
                )
              })}
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 mt-4">
        
        {/* ===== HOME ===== */}
        {activeTab === "home" && (
          <div className="space-y-5">
            <BannerCarousel />
            
            <CategoryNav activeCategory={activeCategory} setActiveCategory={handleCategoryChange} />

            {activeCategory !== "all" && currentCat && (
              <div className="flex items-center gap-2 border-b theme-border pb-2">
                <span className="text-xl">{currentCat.emoji}</span>
                <h2 className="font-display font-bold text-lg theme-text">{currentCat.name}</h2>
                <span className="text-xs theme-muted">({filteredProducts.length} produtos)</span>
              </div>
            )}

            <div className="md:hidden flex items-center theme-surface border theme-border rounded-full px-4 py-2">
              <Search className="w-4 h-4 theme-muted mr-2" />
              <input type="text" placeholder="Pesquisar produtos..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="bg-transparent text-xs w-full focus:outline-none theme-text" />
            </div>

            <div className="grid grid-cols-1 gap-5">
              <div className="col-span-1">
                {filteredProducts.length === 0 ? (
                  <div className="text-center py-16 border border-dashed theme-border rounded-2xl theme-surface"><p className="text-sm theme-muted">Nenhum produto encontrado.</p></div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-3 md:gap-4">
                    {filteredProducts.map((p) => (
                      <div key={p.id} onClick={() => setProductDetailOpen(p)} className="cursor-pointer h-full">
                        <ProductCard product={p} onAddToCart={(prod) => handleAddToCart(prod)} onBuyNow={(prod) => handleBuyNow(prod)} onToggleFavorite={(id, e) => handleToggleFavorite(id, e)} isFavorited={favorites.includes(p.id)} />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ===== FAVORITOS ===== */}
        {activeTab === "favorites" && (
          <div className="space-y-5 py-4">
            <h2 className="font-display font-bold text-lg theme-text border-b theme-border pb-2 flex items-center gap-2"><Heart className="w-5 h-5 text-accent fill-accent" /> Meus Favoritos</h2>
            {filteredProducts.length === 0 ? (
              <div className="text-center py-16 border border-dashed theme-border theme-surface rounded-2xl">
                <Heart className="w-12 h-12 theme-muted mx-auto mb-3" />
                <p className="text-sm font-semibold theme-text-secondary">Você ainda não tem favoritos!</p>
                <button onClick={() => setActiveTab("home")} className="mt-4 py-2 px-5 bg-accent text-white font-bold text-xs uppercase rounded-full cursor-pointer">Explorar Produtos</button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-3 md:gap-4">
                {filteredProducts.map((p) => (
                  <div key={p.id} onClick={() => setProductDetailOpen(p)} className="cursor-pointer h-full">
                    <ProductCard product={p} onAddToCart={(prod) => handleAddToCart(prod)} onBuyNow={(prod) => handleBuyNow(prod)} onToggleFavorite={(id, e) => handleToggleFavorite(id, e)} isFavorited={favorites.includes(p.id)} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ===== DOPAGAMES (Fazenda + Banco + Roleta + Raspadinhas) ===== */}
        {activeTab === "dopagames" && (
          <div className="max-w-4xl mx-auto py-6 px-2 md:px-4">
            
            {/* Casino Header / Nav */}
            <div className="mb-8">
              <h1 className="font-display font-black text-2xl md:text-3xl text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-fuchsia-500 uppercase tracking-widest">
                Bem-vindo ao Cassino
              </h1>
              
              {/* Game Categories */}
              <div className="flex justify-center gap-2 md:gap-4 overflow-x-auto no-scrollbar pb-4 px-2 snap-x">
                {[
                  { id: "bank", label: "DopaBank", emoji: "🏦", color: "from-purple-600 to-indigo-600" },
                  { id: "roulette", label: "Caixas CS", emoji: "🎰", color: "from-yellow-500 to-amber-600" },
                  { id: "crash", label: "Foguetinho", emoji: "🚀", color: "from-red-600 to-orange-600" }
                ].map(game => (
                  <button
                    key={game.id}
                    onClick={() => setActiveGameTab(game.id)}
                    className={`snap-center shrink-0 flex flex-col items-center justify-center p-2 w-[72px] h-[72px] rounded-2xl transition-all border
                      ${activeGameTab === game.id 
                        ? `bg-gradient-to-br ${game.color} border-white/20 shadow-lg scale-105` 
                        : 'bg-black/20 border-white/5 hover:bg-white/5 text-zinc-500 hover:text-zinc-300'
                      }
                    `}
                  >
                    <span className={`text-2xl mb-0.5 ${activeGameTab === game.id ? 'animate-bounce' : ''}`}>{game.emoji}</span>
                    <span className={`text-[8px] font-bold tracking-wider uppercase ${activeGameTab === game.id ? 'text-white' : ''}`}>{game.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Render Active Game - Immersive Mode */}
            <div className="w-full flex justify-center animate-fade-in-up">
              
              {activeGameTab === "bank" && (
                <div className="w-full max-w-2xl">
                  <DopaBank 
                    userData={userData}
                    currentAura={aura} 
                    pixBalance={pixBalance}
                    onUpdateAura={(amount) => setAura(prev => Math.max(0, Math.round((prev + amount) * 10) / 10))} 
                    onUpdatePix={(amount) => setPixBalance(prev => prev + amount)}
                  />
                </div>
              )}

              {activeGameTab === "inventory" && (
                <div className="w-full max-w-2xl">
                  <Inventory 
                    pixBalance={pixBalance} 
                    onUpdatePix={(amount) => setPixBalance(prev => prev + amount)} 
                  />
                </div>
              )}

              {activeGameTab === "crash" && (
                <div className="w-full max-w-3xl">
                  <CrashGame 
                    pixBalance={pixBalance} 
                    onUpdatePix={(amount) => setPixBalance(prev => prev + amount)} 
                  />
                </div>
              )}

              {activeGameTab === "boxes" && (
                <div className="w-full max-w-3xl">
                  <GachaBoxes 
                    currentAura={aura} 
                    onUpdateAura={(amount) => setAura(prev => Math.max(0, Math.round((prev + amount) * 10) / 10))} 
                  />
                </div>
              )}

              {activeGameTab === "farm" && (
                <div className="w-full max-w-4xl">
                  <FarmGame 
                    currentAura={aura} 
                    onUpdateAura={(amount) => setAura(prev => Math.max(0, Math.round((prev + amount) * 10) / 10))} 
                  />
                </div>
              )}

              {activeGameTab === "roulette" && (
                <div className="w-full max-w-5xl">
                  <DiscountRoulette currentAura={aura} pixBalance={pixBalance} onUpdateAura={(amount) => setAura(prev => Math.max(0, Math.round((prev + amount) * 10) / 10))} onUpdatePix={(amount) => setPixBalance(prev => prev + amount)} />
                </div>
              )}

              {activeGameTab === "scratch" && (
                <div className="w-full max-w-2xl space-y-6">
                  <div className="text-center space-y-2">
                    <h2 className="font-display font-extrabold text-2xl theme-text">✨ Raspadinhas</h2>
                    <p className="text-sm theme-text-secondary">Arrisque a sorte raspando cartões!</p>
                  </div>
                  {activeDiscount && (
                    <div className="bg-success/10 border border-success/30 p-3 rounded-xl text-center max-w-sm mx-auto mb-4">
                      <div className="text-xs font-bold text-success">✓ Último Prêmio: <span className="underline">{activeDiscount.code}</span> — {activeDiscount.label}</div>
                    </div>
                  )}
                  <CouponScratcher onCouponReveal={handleCouponReveal} currentAura={aura} onUpdateAura={(amount) => setAura(prev => Math.max(0, Math.round((prev + amount) * 10) / 10))} onWinItem={setWinPrize} />
                </div>
              )}

              {activeGameTab === "clicker" && (
                <div className="w-full max-w-2xl">
                  <BetaClicker 
                    onUpdateAura={(amount) => setAura(prev => Math.max(0, Math.round((prev + amount) * 10) / 10))} 
                  />
                </div>
              )}

            </div>
          </div>
        )}

        {activeTab === "tracking" && <OrderTracking orders={orders} userName={userData?.name} onUpdateOrderCep={(idx, cep, country) => setOrders(prev => prev.map((o, i) => i === idx ? { ...o, cep, country } : o))} />}
        {activeTab === "profile" && <UserProfile user={userData} onSave={setUserData} />}
        {activeTab === "support" && <CreatorSupport />}

        {/* ===== CARRINHO ===== */}
        {activeTab === "cart" && (
          <div className="max-w-2xl mx-auto py-4 space-y-4">
            <h2 className="font-display font-bold text-lg theme-text border-b theme-border pb-2 flex items-center gap-2"><ShoppingBag className="w-5 h-5 text-accent" /> Carrinho</h2>
            {cart.length === 0 ? (
              <div className="text-center py-16 border border-dashed theme-border theme-surface rounded-2xl">
                <ShoppingBag className="w-12 h-12 theme-muted mx-auto mb-3" />
                <p className="text-sm font-semibold theme-text-secondary">Carrinho vazio!</p>
                <button onClick={() => setActiveTab("home")} className="mt-4 py-2 px-5 bg-accent text-white font-bold text-xs uppercase rounded-full cursor-pointer">Ver Produtos</button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  {cart.map((item, index) => (
                    <div key={index} className="theme-card border theme-border p-3 flex items-center justify-between gap-3 rounded-xl">
                      <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg border theme-border" />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-semibold theme-text truncate">{item.name}</h4>
                        <span className="text-[10px] theme-muted uppercase">{item.category}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-display font-bold text-accent">{fmt(item.price)}</span>
                        <button onClick={(e) => handleRemoveFromCart(index, e)} className="theme-muted hover:text-danger p-1 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="theme-surface border theme-border p-4 rounded-2xl space-y-3">
                  <div className="flex justify-between text-xs theme-text-secondary"><span>Subtotal:</span><span className="font-semibold theme-text">{fmt(subtotal)}</span></div>
                  <div className="border-t theme-border pt-3 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] theme-muted uppercase font-bold">Total Estimado</div>
                      <div className="text-lg font-display font-extrabold text-accent">{fmt(subtotal)}</div>
                    </div>
                    <button onClick={() => setCheckoutOpen(true)} className="py-2.5 px-6 bg-accent hover:bg-accent-dark text-white font-display font-bold text-xs uppercase rounded-full cursor-pointer shadow-md animate-glow">
                      Ir para Checkout
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} cartCount={cart.length} onSearchClick={() => { setActiveTab("home"); setTimeout(() => document.querySelector("input[placeholder*='Pesquisar']")?.focus(), 100); }} />

      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cart={cart}
        activeDiscount={activeDiscount}
        onClearCart={() => setCart([])}
        onOrderComplete={handleOrderComplete}
        userName={userData?.name}
        userCep={userData?.cep}
      />

      <ProductDetailModal
        product={productDetailOpen}
        onClose={() => setProductDetailOpen(null)}
        onAddToCart={(p) => { handleAddToCart(p); setProductDetailOpen(null); }}
        onBuyNow={(p) => { handleBuyNow(p); setProductDetailOpen(null); }}
        onToggleFavorite={(id) => handleToggleFavorite(id)}
        isFavorited={productDetailOpen ? favorites.includes(productDetailOpen.id) : false}
      />

      <AuraRanksModal
        isOpen={auraRanksOpen}
        onClose={() => setAuraRanksOpen(false)}
        currentAuraPoints={aura}
        activeTheme={activeTheme}
        onSelectTheme={setActiveTheme}
      />
      <WinPopup prize={winPrize} onClose={() => setWinPrize(null)} />

      {/* Age Gate Modal */}
      {ageGateOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="theme-surface border border-danger/50 p-6 rounded-3xl max-w-sm w-full text-center space-y-5 animate-scale-in">
            <div className="w-16 h-16 bg-danger/20 rounded-full flex items-center justify-center mx-auto text-danger">
              <span className="text-3xl font-bold font-display">18+</span>
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-display font-extrabold text-danger uppercase">Acesso Restrito</h3>
              <p className="text-xs theme-text-secondary">O Mercado Ilícito contém produtos pesados, perigosos e totalmente fora da lei. Você tem certeza que é maior de 18 anos para acessar isso?</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setAgeGateOpen(false)} className="flex-1 py-2.5 rounded-full border border-danger/30 text-danger text-xs font-bold hover:bg-danger/10 transition-colors">Não, sou menor</button>
              <button onClick={() => { setIsAgeVerified(true); setAgeGateOpen(false); setActiveCategory("ilicitos"); }} className="flex-1 py-2.5 rounded-full bg-danger text-white text-xs font-bold hover:bg-red-600 transition-colors shadow-[0_0_15px_rgba(239,68,68,0.5)]">Sim, quero entrar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
