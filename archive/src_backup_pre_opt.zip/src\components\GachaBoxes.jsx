import React, { useState, useRef } from "react";
import { PackageOpen, Sparkles, Gift, Flame, HelpCircle } from "lucide-react";
import { playTick as playTickSound, playWinBig, playLose } from "../audioManager";

export default function GachaBoxes({ currentAura, onUpdateAura }) {
  const [isSpinning, setIsSpinning] = useState(false);
  const [winItem, setWinItem] = useState(null);
  
  // The visual "tape" of items
  const [tapeItems, setTapeItems] = useState([]);
  const tapeRef = useRef(null);
  
  const BOX_COST = 500;

  const PRIZE_POOL = [
    { id: 1, name: "Vazio", rarity: "common", value: 0, color: "border-zinc-500 bg-zinc-800", weight: 60, icon: "💀" },
    { id: 2, name: "Aura Pequena", rarity: "uncommon", value: 200, color: "border-blue-500 bg-blue-900/40", weight: 25, icon: "✨" },
    { id: 3, name: "Aura Média", rarity: "rare", value: 1000, color: "border-purple-500 bg-purple-900/40", weight: 10, icon: "💫" },
    { id: 4, name: "Aura Grande", rarity: "epic", value: 5000, color: "border-fuchsia-500 bg-fuchsia-900/40", weight: 4, icon: "🔥" },
    { id: 5, name: "JACKPOT DOPA", rarity: "legendary", value: 50000, color: "border-yellow-400 bg-yellow-600/40", weight: 1, icon: "👑" },
  ];

  const generateTape = (winningItem) => {
    // Generate 50 random items for the visual spin
    const items = [];
    for (let i = 0; i < 50; i++) {
      // Pick random based on weights, but just for visual
      const rand = Math.random() * 100;
      let selected = PRIZE_POOL[0];
      let sum = 0;
      for (const p of PRIZE_POOL) {
        sum += p.weight;
        if (rand <= sum) { selected = p; break; }
      }
      items.push(selected);
    }
    
    // The winning item will be at index 45
    items[45] = winningItem;
    return items;
  };

  const getWinner = () => {
    const rand = Math.random() * 100;
    let sum = 0;
    for (const p of PRIZE_POOL) {
      sum += p.weight;
      if (rand <= sum) return p;
    }
    return PRIZE_POOL[0];
  };

  const playSound = (type) => {
    if (type === 'tick') playTickSound();
    else if (type === 'win') playWinBig();
    else if (type === 'lose') playLose();
  };

  const openBox = () => {
    if (currentAura < BOX_COST || isSpinning) return;
    onUpdateAura(-BOX_COST);
    setIsSpinning(true);
    setWinItem(null);

    const winner = getWinner();
    const newTape = generateTape(winner);
    setTapeItems(newTape);

    // Reset tape position instantly
    if (tapeRef.current) {
      tapeRef.current.style.transition = 'none';
      tapeRef.current.style.transform = `translateX(0px)`;
    }

    // Force reflow
    void document.body.offsetHeight;

    // Start spin animation (CSS transition)
    // We want to land on item index 45. Each item is e.g. 120px wide + 16px gap = 136px.
    // Center of screen needs to align with center of item 45.
    // Let's just translate a fixed amount and use CSS trickery.
    const ITEM_WIDTH = 136; 
    const targetX = -(45 * ITEM_WIDTH) + (window.innerWidth < 768 ? 100 : 250); 
    
    // Add random slight offset so it doesn't land perfectly dead center every time
    const offset = (Math.random() - 0.5) * 80;
    const finalX = targetX + offset;

    setTimeout(() => {
      if (tapeRef.current) {
        tapeRef.current.style.transition = 'transform 5s cubic-bezier(0.1, 0, 0, 1)'; // very fast start, very slow end
        tapeRef.current.style.transform = `translateX(${finalX}px)`;
      }
      
      // Simulate ticking sound
      let ticks = 0;
      const tickInterval = setInterval(() => {
        playSound('tick');
        ticks++;
        if (ticks > 40) clearInterval(tickInterval);
      }, 100);

      // Finish spin
      setTimeout(() => {
        setIsSpinning(false);
        setWinItem(winner);
        if (winner.value > 0) {
          playSound('win');
          onUpdateAura(winner.value);
        } else {
          playSound('lose');
        }
      }, 5200);

    }, 50);
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-[#0F172A] rounded-[32px] overflow-hidden shadow-2xl border-4 border-[#1E293B] font-sans">
      
      <div className="bg-[#1E293B] px-6 py-4 flex justify-between items-center border-b border-[#334155]">
        <div className="flex items-center gap-2">
          <PackageOpen className="w-6 h-6 text-fuchsia-400" />
          <h2 className="font-display font-black text-xl text-white tracking-wider">CAIXAS DOPA</h2>
        </div>
        <div className="text-xs font-bold text-zinc-400">Mistério</div>
      </div>

      <div className="p-6">
        
        {/* Roulette Window */}
        <div className="relative h-40 bg-[#020617] rounded-2xl overflow-hidden border-2 border-[#334155] shadow-inner mb-6">
          
          {/* Target Line (Center) */}
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-1 bg-yellow-400 z-10 shadow-[0_0_15px_#FACC15]"></div>
          
          {/* Tape */}
          <div className="absolute top-0 bottom-0 left-0 flex items-center gap-4 px-[50vw]" ref={tapeRef} style={{ willChange: 'transform' }}>
            {tapeItems.length > 0 ? tapeItems.map((item, idx) => (
              <div key={idx} className={`w-[120px] h-[120px] shrink-0 rounded-xl border-b-4 flex flex-col items-center justify-center gap-2 shadow-lg ${item.color}`}>
                <span className="text-4xl drop-shadow-md">{item.icon}</span>
                <span className="text-[10px] font-bold text-white uppercase tracking-wider text-center px-1">{item.name}</span>
              </div>
            )) : (
              // Initial empty state
              [...Array(10)].map((_, idx) => (
                 <div key={idx} className="w-[120px] h-[120px] shrink-0 rounded-xl border-b-4 border-zinc-700 bg-zinc-800/50 flex items-center justify-center">
                   <HelpCircle className="w-8 h-8 text-zinc-600" />
                 </div>
              ))
            )}
          </div>
          
          {/* Shadows */}
          <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-[#020617] to-transparent z-10"></div>
          <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-[#020617] to-transparent z-10"></div>
        </div>

        {/* Win Result */}
        <div className="h-20 flex items-center justify-center mb-6">
          {winItem && (
            <div className={`px-8 py-3 rounded-2xl border-2 flex items-center gap-4 animate-scale-in ${winItem.value > 0 ? 'bg-emerald-900/30 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]' : 'bg-red-900/30 border-red-500'}`}>
              <span className="text-3xl">{winItem.icon}</span>
              <div>
                <div className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Você tirou:</div>
                <div className={`font-black text-xl ${winItem.value > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {winItem.name} {winItem.value > 0 ? `(+${winItem.value} Aura)` : ''}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex justify-center">
          <button 
            onClick={openBox}
            disabled={isSpinning || currentAura < BOX_COST}
            className={`flex items-center gap-3 px-10 py-5 rounded-2xl font-black text-2xl uppercase tracking-widest transition-all
              ${isSpinning ? 'bg-zinc-700 text-zinc-500 cursor-not-allowed shadow-none' 
                : currentAura < BOX_COST ? 'bg-red-900/50 text-red-500 cursor-not-allowed'
                : 'bg-fuchsia-600 hover:bg-fuchsia-500 text-white shadow-[0_6px_0_#86198F] hover:shadow-[0_4px_0_#86198F] hover:translate-y-0.5 active:shadow-none active:translate-y-1.5'
              }
            `}
          >
            {isSpinning ? 'Abrindo...' : (
              <>
                <Gift className="w-6 h-6" /> Abrir Caixa ({BOX_COST})
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
}
