import React, { useState, useEffect, useRef } from "react";
import { Rocket, AlertOctagon, CheckCircle2, RotateCcw } from "lucide-react";
import { playCrash, playCashout, playCrashTick } from "../audioManager";

export default function CrashGame({ pixBalance, onUpdatePix }) {
  const [gameState, setGameState] = useState("idle"); // idle, playing, crashed
  const [cashedOut, setCashedOut] = useState(false);
  const [multiplier, setMultiplier] = useState(1.00);
  const [bet, setBet] = useState(100);
  const [history, setHistory] = useState([]);
  const [winAmount, setWinAmount] = useState(0);
  const [graphData, setGraphData] = useState({ x: 0, y: 0, elapsed: 0 });

  const multiplierRef = useRef(1.00);
  const crashPointRef = useRef(1.00);
  const rafRef = useRef(null);
  const startTimeRef = useRef(null);

  // Casino sound helper (uses global singleton)
  const playSound = (type) => {
    if (type === 'tick') playCrashTick(multiplierRef.current);
    else if (type === 'crash') playCrash();
    else if (type === 'cashout') playCashout();
  };

  const getCrashPoint = () => {
    // Matemática ajustada para gerar "velas" mais altas com mais frequência
    const r = Math.random();
    
    // 3% de chance de crash instantâneo no 1.00x para manter a tensão
    if (r < 0.03) return 1.00;
    
    // Usando uma curva de potência (1.35) para gerar multiplicadores maiores mais facilmente
    // Em vez da mediana ser 1.99x (realidade), a mediana agora será perto de 2.6x
    const raw = 1 / Math.pow(1 - r, 1.35);
    
    return Math.max(1.00, parseFloat(raw.toFixed(2)));
  };

  const startGame = () => {
    if (pixBalance < bet || bet < 1) return;
    onUpdatePix(-bet);
    
    crashPointRef.current = getCrashPoint();
    multiplierRef.current = 1.00;
    
    setMultiplier(1.00);
    setGameState("playing");
    setCashedOut(false);
    setWinAmount(0);
    setGraphData({ x: 0, y: 0, elapsed: 0 });
    
    startTimeRef.current = performance.now();
    
    const updateGame = (time) => {
      if (!startTimeRef.current) startTimeRef.current = time;
      const elapsed = time - startTimeRef.current;
      
      // Exponential curve: multiplier = Math.E ^ (elapsed * rate)
      const newMult = Math.exp(elapsed * 0.00015);
      
      if (newMult >= crashPointRef.current) {
        triggerCrash(crashPointRef.current);
      } else {
        multiplierRef.current = newMult;
        setMultiplier(newMult);
        
        // Calculate graph positions
        // x moves right logarithmically or linearly, y moves up exponentially
        const xPos = Math.min(95, elapsed / 80); // cap at 95% width
        const yPos = Math.min(85, (newMult - 1) * 12); // cap at 85% height
        setGraphData({ x: xPos, y: yPos, elapsed });

        if (Math.random() > 0.8) playSound('tick');
        rafRef.current = requestAnimationFrame(updateGame);
      }
    };
    
    rafRef.current = requestAnimationFrame(updateGame);
  };

  const triggerCrash = (finalMult) => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    playSound('crash');
    setGameState("crashed");
    setMultiplier(finalMult);
    addToHistory(finalMult);
  };

  const cashOut = () => {
    if (gameState !== "playing" || cashedOut) return;
    playSound('cashout');
    setCashedOut(true);
    
    const payout = bet * multiplierRef.current;
    setWinAmount(payout);
    onUpdatePix(payout);
  };

  const addToHistory = (mult) => {
    setHistory(prev => [{ id: Date.now(), mult }, ...prev].slice(0, 10));
  };

  // Generate SVG path for the curve
  const pathD = `M 0 100 Q ${graphData.x * 0.6} 100 ${graphData.x} ${100 - graphData.y} L ${graphData.x} 100 Z`;
  const strokePathD = `M 0 100 Q ${graphData.x * 0.6} 100 ${graphData.x} ${100 - graphData.y}`;

  return (
    <div className="w-full max-w-3xl mx-auto bg-[#1A1C23] rounded-[32px] overflow-hidden shadow-2xl border-4 border-[#2A2E3B] select-none font-sans">
      
      {/* Header */}
      <div className="bg-[#21242D] px-6 py-4 flex justify-between items-center border-b border-[#2A2E3B]">
        <div className="flex items-center gap-2">
          <Rocket className="w-6 h-6 text-red-500" />
          <h2 className="font-display font-black text-xl text-white tracking-wider">DOPA-CRASH</h2>
        </div>
        <div className="bg-[#1A1C23] px-4 py-1.5 rounded-full border border-[#2A2E3B] flex gap-2 overflow-hidden max-w-[50%]">
          {history.map((h) => (
            <span key={h.id} className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${h.mult < 2 ? 'bg-zinc-800 text-zinc-400' : h.mult < 10 ? 'bg-blue-900/50 text-blue-400' : 'bg-yellow-900/50 text-yellow-400'}`}>
              {h.mult.toFixed(2)}x
            </span>
          ))}
        </div>
      </div>

      {/* Main Graph Area */}
      <div className="relative h-72 md:h-96 bg-[#121419] flex flex-col items-center justify-center overflow-hidden">
        
        {/* Background Grid Lines */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCI+PHBhdGggZD0iTTAgMGg0MHY0MEgweiIgZmlsbD0ibm9uZSIvPjxwYXRoIGQ9Ik0wIDM5LTVoNDBNMzkuNSAwdi00MCIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIiBzdHJva2Utd2lkdGg9IjEiLz48L3N2Zz4=')]"></div>

        {/* SVG Graph Curve */}
        {(gameState === 'playing' || gameState === 'crashed') && (
          <div className="absolute inset-0 pointer-events-none">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full opacity-60">
              <defs>
                <linearGradient id="curveGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#EF4444" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#EF4444" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path d={pathD} fill="url(#curveGradient)" />
              <path d={strokePathD} fill="none" stroke="#EF4444" strokeWidth="0.5" />
            </svg>
          </div>
        )}

        {/* Rocket Icon */}
        {(gameState === 'playing' || gameState === 'crashed') && (
          <div 
             className="absolute transition-all duration-75 ease-linear pointer-events-none"
             style={{ 
               bottom: `${graphData.y}%`,
               left: `${graphData.x}%`,
               transform: 'translate(-50%, 50%)'
             }}
          >
             <div className="relative">
               <div className={`relative z-10 ${gameState === 'crashed' ? 'grayscale brightness-50' : ''}`}>
                 <Rocket className={`w-12 h-12 md:w-16 md:h-16 text-red-500 drop-shadow-[0_0_15px_rgba(239,68,68,0.8)] ${gameState === 'playing' ? 'animate-pulse' : ''}`} style={{ transform: 'rotate(45deg)' }} />
                 
                 {/* Fire exhaust */}
                 {gameState === 'playing' && (
                   <div className="absolute bottom-0 left-0 w-8 h-8 bg-gradient-to-tr from-yellow-400 to-orange-600 rounded-full blur-md animate-ping opacity-80" style={{ transform: 'translate(-20%, 20%)' }}></div>
                 )}

                 {/* Explosion Effect */}
                 {gameState === 'crashed' && (
                   <div className="absolute inset-0 flex items-center justify-center">
                     <div className="absolute w-32 h-32 bg-red-600 rounded-full blur-xl opacity-60 animate-pulse"></div>
                     <div className="text-5xl">💥</div>
                   </div>
                 )}
               </div>
             </div>
          </div>
        )}

        {/* Central Multiplier */}
        <div className="relative z-10 text-center">
          <div className={`font-black text-7xl md:text-9xl tabular-nums tracking-tighter transition-colors duration-150
            ${gameState === 'crashed' ? 'text-red-500' : cashedOut ? 'text-emerald-400' : 'text-white'}
            ${gameState === 'playing' && multiplier > 10 && !cashedOut ? 'animate-pulse text-yellow-400' : ''}
          `}>
            {multiplier.toFixed(2)}x
          </div>
          
          {gameState === 'crashed' && (
            <div className="mt-4 flex items-center justify-center gap-2 text-red-500 animate-scale-in">
              <AlertOctagon className="w-6 h-6" />
              <span className="font-bold uppercase tracking-widest text-lg">Explodiu @ {multiplier.toFixed(2)}x</span>
            </div>
          )}
          
          {cashedOut && (
            <div className="mt-4 flex flex-col items-center justify-center gap-1 text-emerald-400 animate-scale-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                <span className="font-bold uppercase tracking-widest">Retirou Seguro</span>
              </div>
              <div className="font-black text-2xl">+R$ {winAmount.toFixed(2)}</div>
            </div>
          )}
          
          {gameState === 'idle' && (
            <div className="mt-4 text-zinc-500 font-bold uppercase tracking-widest text-sm">Aguardando Aposta</div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="bg-[#21242D] p-6 flex flex-col md:flex-row gap-4">
        
        <div className="flex-1 bg-[#1A1C23] rounded-2xl p-4 border border-[#2A2E3B]">
          <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Sua Aposta (R$)</label>
          <div className="flex items-center bg-[#121419] rounded-xl border border-[#2A2E3B] overflow-hidden">
            <input 
              type="number" 
              value={bet} 
              onChange={(e) => setBet(Number(e.target.value))}
              disabled={gameState === 'playing'}
              className="w-full bg-transparent text-white font-bold text-lg p-3 outline-none"
            />
            <div className="flex gap-1 pr-2">
              <button onClick={() => setBet(Math.floor(bet / 2))} disabled={gameState === 'playing'} className="bg-[#2A2E3B] hover:bg-[#3A3F51] text-xs font-bold text-white px-3 py-1.5 rounded transition-colors">/2</button>
              <button onClick={() => setBet(Math.floor(bet * 2))} disabled={gameState === 'playing'} className="bg-[#2A2E3B] hover:bg-[#3A3F51] text-xs font-bold text-white px-3 py-1.5 rounded transition-colors">x2</button>
              <button onClick={() => setBet(Math.floor(pixBalance))} disabled={gameState === 'playing'} className="bg-[#2A2E3B] hover:bg-[#3A3F51] text-xs font-bold text-white px-3 py-1.5 rounded transition-colors">MAX</button>
            </div>
          </div>
        </div>

        <div className="flex-1 flex">
          {gameState === 'idle' || gameState === 'crashed' ? (
            <button 
              onClick={startGame}
              disabled={pixBalance < bet || bet < 1}
              className={`w-full rounded-2xl font-black text-2xl uppercase tracking-widest transition-all shadow-[0_6px_0_#0F766E] hover:shadow-[0_4px_0_#0F766E] hover:translate-y-0.5 active:shadow-none active:translate-y-1.5 flex items-center justify-center gap-3
                ${pixBalance < bet ? 'bg-zinc-700 text-zinc-500 shadow-none cursor-not-allowed' : 'bg-emerald-500 text-white'}
              `}
            >
              {gameState === 'crashed' ? <><RotateCcw className="w-6 h-6" /> Nova Aposta</> : 'Apostar'}
            </button>
          ) : (
            <button 
              onClick={cashOut}
              disabled={cashedOut}
              className={`w-full rounded-2xl font-black text-2xl uppercase tracking-widest transition-all shadow-[0_6px_0_#991B1B]
                ${cashedOut ? 'bg-emerald-900 text-emerald-500 shadow-none border-2 border-emerald-500/30' : 'bg-red-500 text-white hover:bg-red-400 active:shadow-none active:translate-y-1.5'}
              `}
            >
              {cashedOut ? 'Aguardando...' : (
                <div className="flex flex-col items-center">
                  <span>RETIRAR</span>
                  <span className="text-xs text-red-200">R$ {(bet * multiplier).toFixed(2)}</span>
                </div>
              )}
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
