import React, { useState, useRef, useEffect } from "react";
import { ArrowLeft, Heart, Volume2, VolumeX, FastForward, Zap, Star } from "lucide-react";
import confetti from "canvas-confetti";
import { playHover as playHoverAM, playClick as playClickAM, playCSWinSynth, initAudio } from "../audioManager";

const rarities = {
  milspec: { name: 'Nível Militar', color: 'text-blue-500', hex: '#3b82f6', bg: 'from-blue-900 to-black', border: 'border-blue-600', glow: 'shadow-[0_0_10px_rgba(37,99,235,0.3)]' },
  restricted: { name: 'Restrito', color: 'text-purple-500', hex: '#a855f7', bg: 'from-purple-900 to-black', border: 'border-purple-600', glow: 'shadow-[0_0_15px_rgba(147,51,234,0.4)]' },
  classified: { name: 'Confidencial', color: 'text-pink-400', hex: '#f472b6', bg: 'from-pink-900 to-black', border: 'border-pink-500', glow: 'shadow-[0_0_20px_rgba(236,72,153,0.5)]' },
  covert: { name: 'Oculto', color: 'text-red-500', hex: '#ef4444', bg: 'from-red-900 to-black', border: 'border-red-600', glow: 'shadow-[0_0_30px_rgba(220,38,38,0.6)]' },
  gold: { name: 'Item Especial', color: 'text-yellow-400', hex: '#facc15', bg: 'from-yellow-700 to-black', border: 'border-yellow-400', glow: 'shadow-[0_0_40px_rgba(250,204,21,0.8)]' },
};

const ITEM_SIZE = 154; 

const getRandomItem = (caseItems) => {
  const rand = Math.random() * 100;
  let rarityStr = 'milspec';
  
  // Chances Reais Oficiais do CS:GO
  if (rand <= 0.256) rarityStr = 'gold'; // 0.256%
  else if (rand <= 0.895) rarityStr = 'covert'; // 0.639% (0.256 + 0.639)
  else if (rand <= 4.092) rarityStr = 'classified'; // 3.197% (0.895 + 3.197)
  else if (rand <= 20.077) rarityStr = 'restricted'; // 15.985% (4.092 + 15.985)
  else rarityStr = 'milspec'; // 79.923%

  let pool = caseItems.filter(i => i.rarity === rarityStr);
  if (pool.length === 0) pool = caseItems.filter(i => i.rarity === 'milspec');
  if (pool.length === 0) pool = caseItems; // Fallback extremo para evitar crash
  return pool[Math.floor(Math.random() * pool.length)];
};

const tickAudioBase = typeof window !== 'undefined' ? new Audio('/sounds/csgo_ui_crate_item_scroll.wav') : null;
let lastTickTime = 0;

const GOLD_PLACEHOLDER = {
  id: 'rare-special-placeholder',
  rarity: 'gold',
  name: '★ Rare Special Item ★',
  icon: '★',
  image: '/rare_special.png',
  isPlaceholder: true,
  price: 0
};

const generateTrack = (winnerIndex, forcedWinner, caseItems) => {
  const track = [];
  for (let i = 0; i < 100; i++) {
    if (i === winnerIndex && forcedWinner) {
      // Se o item for gold, colocamos o placeholder dourado na roleta principal
      if (forcedWinner.rarity === 'gold') {
        track.push({ id: i, item: { ...GOLD_PLACEHOLDER }, rData: rarities['gold'] });
      } else {
        track.push({ id: i, item: forcedWinner, rData: rarities[forcedWinner.rarity] });
      }
    } else {
      const item = getRandomItem(caseItems);
      // Itens gold aleatórios na pista também viram placeholder
      if (item.rarity === 'gold') {
        track.push({ id: i, item: { ...GOLD_PLACEHOLDER }, rData: rarities['gold'] });
      } else {
        track.push({ id: i, item, rData: rarities[item.rarity] });
      }
    }
  }
  return track;
};

const HexagonBg = ({ color, glow = true }) => (
  <div className="absolute inset-0 flex items-center justify-center pointer-events-none scale-[0.85]">
     {/* Outer Hexagon - faint and thin */}
     <svg viewBox="0 0 100 115" className="absolute w-[115%] h-[115%] z-0 opacity-30" style={{ color }}>
        <polygon points="50,2 98,28 98,87 50,113 2,87 2,28" fill="transparent" stroke="currentColor" strokeWidth="1" />
     </svg>
     {/* Inner Hexagon - thick, bright, matching rarity */}
     <svg viewBox="0 0 100 115" className="absolute w-full h-full z-0 opacity-100" style={{ color }}>
        <polygon points="50,2 98,28 98,87 50,113 2,87 2,28" fill="currentColor" fillOpacity="0.05" stroke="currentColor" strokeWidth="2.5" style={glow ? {filter: `drop-shadow(0 0 6px ${color})`} : {}} />
     </svg>
  </div>
);

const HexagonSVG = ({ color, opacity = "0.1" }) => (
  <svg viewBox="0 0 100 115" className="absolute inset-0 w-full h-full z-0 drop-shadow-md" style={{ color }}>
     <polygon points="50,2 98,28 98,87 50,113 2,87 2,28" fill="transparent" stroke="currentColor" strokeWidth="2" />
     <polygon points="50,2 98,28 98,87 50,113 2,87 2,28" fill="currentColor" opacity={opacity} />
  </svg>
);

const HexButton = ({ children, active, onClick, title }) => (
  <button onClick={onClick} title={title} className="w-[48px] h-[48px] md:w-10 md:h-10 relative flex items-center justify-center text-zinc-400 hover:text-white transition-all group cursor-pointer hover:scale-110 active:scale-95 touch-manipulation">
     <svg viewBox="0 0 100 115" className={`absolute inset-0 w-full h-full transition-colors ${active ? 'text-zinc-600' : 'text-zinc-800 group-hover:text-zinc-700'}`}>
        <polygon points="50,2 98,28 98,87 50,113 2,87 2,28" fill="currentColor" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
     </svg>
     <div className="relative z-10">{children}</div>
  </button>
);

export default function DiscountRoulette({ currentAura, onUpdateAura, pixBalance, onUpdatePix }) {
  const [tab, setTab] = useState('cases'); // 'cases' | 'inventory'
  const [view, setView] = useState('selector'); // 'selector' | 'opener'
  const [activeCase, setActiveCase] = useState(null);
  const [tracks, setTracks] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [inventory, setInventory] = useState([]);
  
  const [spinning, setSpinning] = useState(false);
  const [finished, setFinished] = useState(false);
  const [offsets, setOffsets] = useState([]);
  const [winnerIndices, setWinnerIndices] = useState([]);
  const [results, setResults] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [openCount, setOpenCount] = useState(1);
  const [muted, setMuted] = useState(false);
  const [goldSpinPhase, setGoldSpinPhase] = useState(false);
  const [goldTrack, setGoldTrack] = useState([]);
  const [goldOffset, setGoldOffset] = useState(0);
  const [goldWinnerIndex, setGoldWinnerIndex] = useState(0);
  const [goldSpinning, setGoldSpinning] = useState(false);
  const [pendingWinners, setPendingWinners] = useState([]);
  const [favoriteCases, setFavoriteCases] = useState(() => {
    try { return JSON.parse(localStorage.getItem('dopashop_fav_cases')) || []; } catch { return []; }
  });
  
  const containerRefs = useRef([]);
  const goldContainerRef = useRef(null);

  const [casesData, setCasesData] = useState([]);
  const [loadingCases, setLoadingCases] = useState(true);

  useEffect(() => {
    fetch('https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/crates.json')
      .then(res => res.json())
      .then(data => {
        const cases = data.filter(c => c.type === 'Case' && c.contains && c.contains.length > 0);
        
        const transformedCases = cases.map(c => {
          
          // Preços mapeados da screenshot oficial (em BRL)
          const priceMap = {
             "Kilowatt": 9.00,
             "Fracture": 10.80,
             "Revolution": 11.40,
             "Recoil": 11.70,
             "Snakebite": 16.50,
             "Danger Zone": 18.00,
             "Dreams & Nightmares": 22.20,
             "Prisma 2": 25.50,
             "Shattered Web": 38.70,
             "Phoenix": 39.00,
             "Broken Fang": 45.00,
             "Breakout": 47.40,
             "Spectrum": 47.70,
             "Huntsman": 49.50,
             "Riptide": 56.10,
             "Weapon Case 3": 90.60,
             "Weapon Case 2": 173.10,
             "Hydra": 177.30,
             "Bravo": 202.20,
          };
          
          let casePrice = 15.00; // Fallback
          if (c.name === "CS:GO Weapon Case") {
             casePrice = 408.60;
          } else {
             for (const [key, val] of Object.entries(priceMap)) {
               if (c.name.includes(key)) {
                  casePrice = val;
                  break;
               }
             }
          }

          const mapRarity = (item) => {
            if (!item.rarity) return 'milspec';
            if (item.rarity.color === '#eb4b4b') return 'covert';
            if (item.rarity.color === '#d32ce6') return 'classified';
            if (item.rarity.color === '#8847ff') return 'restricted';
            if (item.rarity.color === '#4b69ff') return 'milspec';
            return 'milspec';
          };

          const parseItem = (item, isRare = false) => {
             let r = isRare ? 'gold' : mapRarity(item);
             
             // A economia agora é proporcional ao valor da caixa
             // Caixas mais caras dropam itens básicos mais valiosos (como na vida real com as Coleções Antigas)
             let price = casePrice * 0.15 + (Math.random() * casePrice * 0.1); 
             if(r === 'restricted') price = casePrice * 0.6 + (Math.random() * casePrice * 0.8);
             if(r === 'classified') price = casePrice * 2.5 + (Math.random() * casePrice * 4);
             if(r === 'covert') price = casePrice * 12 + (Math.random() * casePrice * 25);
             if(r === 'gold') price = casePrice * 80 + (Math.random() * casePrice * 200);

             return {
               id: item.id || `rare-${Math.random()}`,
               rarity: r,
               name: item.name,
               icon: isRare ? '🔪' : (item.name.includes('AWP') || item.name.includes('SSG') ? '🔭' : (item.name.includes('Gloves') || item.name.includes('Hand Wraps') ? '🧤' : '🔫')),
               price: parseFloat(price.toFixed(2)),
               image: item.image
             };
          };

          let allItems = [];
          if(c.contains) {
             allItems = [...allItems, ...c.contains.map(i => parseItem(i, false))];
          }
          if(c.contains_rare) {
             const rareSample = c.contains_rare.slice(0, 15);
             allItems = [...allItems, ...rareSample.map(i => parseItem(i, true))];
          }

          return {
            id: c.id,
            name: c.name,
            image: c.image,
            price: casePrice,
            items: allItems
          };
        });
        
        setCasesData(transformedCases.reverse());
        setLoadingCases(false);
      })
      .catch(err => {
        console.error("Erro ao carregar caixas da API:", err);
        setLoadingCases(false);
      });
  }, []);

  useEffect(() => {
    try {
      const inv = JSON.parse(localStorage.getItem('dopashop_inventory')) || [];
      const csgoItems = inv.filter(i => i.rarity); // Filtra apenas itens do CS
      setInventory(csgoItems);
    } catch(e) {}
  }, [tab, showPopup]);

  useEffect(() => {
    const doInit = () => initAudio();
    window.addEventListener('click', doInit, { once: true });
    window.addEventListener('touchstart', doInit, { once: true });
    return () => {
      window.removeEventListener('click', doInit);
      window.removeEventListener('touchstart', doInit);
    };
  }, []);

  const playTick = () => {
    if (muted || !tickAudioBase) return;
    const now = performance.now();
    // Permite a velocidade real do CS (o "BRRRR" do começo), limitando apenas a 10ms para o navegador não travar
    if (now - lastTickTime < 10) return; 
    lastTickTime = now;
    
    try {
        const cloned = tickAudioBase.cloneNode();
        cloned.volume = 0.50; // Volume clássico punchy do CS
        cloned.play().catch(() => {});
    } catch(e) {}
  };

  const playWinSound = (rarity) => {
    if (muted) return;
    
    // Som físico imediato de destrancar a caixa (Feedback instantâneo sem delay de "attack" musical)
    try {
      const clickAudio = new Audio('/sounds/case-unlock-immediate-csgo.mp3');
      clickAudio.volume = 0.4;
      clickAudio.play();
    } catch (e) {}

    const soundMap = {
      milspec: '/sounds/case_awarded_1_uncommon_01.wav',
      restricted: '/sounds/case_awarded_2_rare_01.wav',
      classified: '/sounds/case_awarded_3_mythical_01.wav',
      covert: '/sounds/case_awarded_4_legendary_01.wav',
      gold: '/sounds/case_awarded_5_ancient_01.wav'
    };

    // Tocar o arquivo base da Valve (que tem diferenças muito sutis)
    try {
      const audio = new Audio(soundMap[rarity] || soundMap['milspec']);
      audio.volume = 0.5; // Abaixa o volume do base para destacar a diferença sintética
      audio.play();
    } catch (e) {}

    // Synth layer per rarity (uses global AudioManager)
    if (!muted) {
      playCSWinSynth(rarity);
    }
  };

  const playAcceptSound = () => {
    if (muted) return;
    try {
      const audio = new Audio('/sounds/inventory_new_item_accept_01.wav');
      audio.volume = 0.7;
      audio.play();
    } catch (e) {}
  };

  const playHoverSound = () => {
    if (muted) return;
    playHoverAM();
  };

  const playClickSound = () => {
    if (muted) return;
    playClickAM();
  };

  const sellItemNow = () => {
    if (!results || results.length === 0) return;
    
    const currentResults = [...results];
    setResults([]); // Previne duplo clique imediato
    
    playAcceptSound();
    
    let totalValue = 0;
    currentResults.forEach(res => { totalValue += res.item.price; });

    if (onUpdatePix) onUpdatePix(totalValue);
    
    try {
      let inv = JSON.parse(localStorage.getItem('dopashop_inventory')) || [];
      currentResults.forEach(res => {
         let found = false;
         inv = inv.map(i => {
           if (i.id === res.item.id && !found) {
             found = true;
             return { ...i, count: i.count - 1 };
           }
           return i;
         });
      });
      inv = inv.filter(i => i.count > 0);
      localStorage.setItem('dopashop_inventory', JSON.stringify(inv));
      setInventory(inv);
    } catch(e) {}

    setShowPopup(false);

    // Abre a próxima caixa automaticamente se tiver saldo (considerando o novo saldo + o que acabou de vender)
    setTimeout(() => {
        openCase();
    }, 150);
  };

  const sellInventoryItem = (item) => {
    if (onUpdatePix) onUpdatePix(item.price);
    try {
      let inv = JSON.parse(localStorage.getItem('dopashop_inventory')) || [];
      inv = inv.map(i => {
        if (i.id === item.id) {
          return { ...i, count: i.count - 1 };
        }
        return i;
      }).filter(i => i.count > 0);
      localStorage.setItem('dopashop_inventory', JSON.stringify(inv));
      setInventory(inv);
    } catch(e) {}
  };

  const sellAllItems = () => {
    let totalValue = 0;
    inventory.forEach(item => { totalValue += (item.price * item.count); });
    
    if (totalValue > 0) {
       if (onUpdatePix) onUpdatePix(totalValue);
       playAcceptSound();
       
       try {
           let inv = JSON.parse(localStorage.getItem('dopashop_inventory')) || [];
           // Remove apenas os itens que tem 'rarity' (que são do CS)
           inv = inv.filter(i => !i.rarity);
           localStorage.setItem('dopashop_inventory', JSON.stringify(inv));
           setInventory([]);
       } catch(e) {}
    }
  };

  const handleSelectCase = (c) => {
    playClickSound();
    setActiveCase(c);
    setTracks([generateTrack(0, null, c.items).slice(0, 20)]);
    setOffsets([0]);
    setView('opener');
  };

  const openCase = (e) => {
    if (spinning || !activeCase || pixBalance < (activeCase.price * openCount)) return;
    
    if (onUpdatePix) onUpdatePix(-(activeCase.price * openCount));
    
    initAudio();
    
    // CRÍTICO: Não ative 'spinning' ainda, caso contrário o reset para offset 0 vai ser animado em 6.5s (o que causa o bug de "roleta travada/voltando")
    setSpinning(false); 
    setFinished(false);
    setResults([]);
    setShowPopup(false);

    if (!muted) {
      try {
        const startAudio = new Audio('/sounds/csgo_ui_crate_open.wav');
        startAudio.volume = 0.5;
        startAudio.play();
      } catch(e) {}
    }

    const newTracks = [];
    const newIndices = [];
    const newOffsets = [];

    for (let i = 0; i < openCount; i++) {
        const newWinnerIndex = 75 + Math.floor(Math.random() * 10);
        newIndices.push(newWinnerIndex);
        
        const winnerItem = getRandomItem(activeCase.items);
        // Guardamos o item REAL (faca/luva) numa referência separada se for gold
        const realGoldItem = winnerItem.rarity === 'gold' ? winnerItem : null;
        newTracks.push({ track: generateTrack(newWinnerIndex, winnerItem, activeCase.items), realGoldItem });
        newOffsets.push(0);
    }

    setWinnerIndices(newIndices);
    setTracks(newTracks.map(t => t.track));
    // Guardar referências dos itens gold reais para a segunda roleta
    containerRefs.current._realGoldItems = newTracks.map(t => t.realGoldItem);
    setOffsets(newOffsets); // Reset instantâneo para 0

    setTimeout(() => {
      if (!containerRefs.current[0]) return;
      
      // Agora sim ligamos a transição CSS, e definimos o offset alvo
      setSpinning(true);

      const targetOffsets = newIndices.map(wIndex => {
          const randomStopOffset = Math.floor(Math.random() * 140) - 70;
          return -((wIndex * ITEM_SIZE) + randomStopOffset);
      });
      setOffsets(targetOffsets);

      let currentItemIndex = 0;
      let animationFrameId;

      const checkPosition = () => {
        const mainContainer = containerRefs.current[0];
        if (!mainContainer) return;
        const style = window.getComputedStyle(mainContainer);
        let currentPos = 0;
        const match3d = style.transform.match(/matrix3d\((.+)\)/);
        if (match3d) {
           const values = match3d[1].split(', ');
           // In matrix3d: index 12 is translateX, index 13 is translateY
           currentPos = Math.abs(parseFloat(openCount > 1 ? values[13] : values[12]));
        } else {
           const match2d = style.transform.match(/matrix\((.+)\)/);
           if (match2d) {
              const values = match2d[1].split(', ');
              // In matrix: index 4 is translateX, index 5 is translateY
              currentPos = Math.abs(parseFloat(openCount > 1 ? values[5] : values[4]));
           }
        }

        const index = Math.floor((currentPos + (ITEM_SIZE/2)) / ITEM_SIZE);
        
        if (index > currentItemIndex) {
          currentItemIndex = index;
          playTick();
        }
        
        if (mainContainer.dataset.spinning === 'true') {
          animationFrameId = requestAnimationFrame(checkPosition);
        }
      };
      
      containerRefs.current[0].dataset.spinning = 'true';
      animationFrameId = requestAnimationFrame(checkPosition);

      // The stop logic is now handled by onTransitionEnd on the container
    }, 50);
  };

  const handleSpinEnd = (e) => {
    if (e && e.target !== containerRefs.current[0]) return;
    if (e && e.propertyName !== 'transform') return;
    if (!spinning || finished) return;
    
    setFinished(true);
    setSpinning(false);
    if (containerRefs.current[0]) containerRefs.current[0].dataset.spinning = 'false';

    const winners = [];
    for(let i=0; i<openCount; i++){
        if(tracks[i] && tracks[i][winnerIndices[i]]) {
            const trackWinner = JSON.parse(JSON.stringify(tracks[i][winnerIndices[i]]));
            // Se era um placeholder gold, substituímos pelo item real guardado
            if (trackWinner.item.isPlaceholder && containerRefs.current._realGoldItems && containerRefs.current._realGoldItems[i]) {
                trackWinner.item = { ...containerRefs.current._realGoldItems[i] };
                trackWinner.item._wasGoldPlaceholder = true; // Sinaliza que precisa de segunda roleta
            }
            winners.push(trackWinner);
        }
    }
    
    if (winners.length === 0) return;
    
    // Verifica se algum winner era um gold placeholder → segunda roleta
    const hasGold = winners.some(w => w.item._wasGoldPlaceholder);
    
    if (hasGold) {
        // Guarda os winners normais para depois e inicia a segunda roleta
        setPendingWinners(winners);
        startGoldSpin(winners);
        return;
    }
    
    // Fluxo normal: mostra popup
    finalizeResults(winners);
  };

  const startGoldSpin = (winners) => {
    // Pegar apenas os itens gold da caixa ativa
    const goldItems = activeCase.items.filter(i => i.rarity === 'gold');
    if (goldItems.length === 0) {
        finalizeResults(winners);
        return;
    }
    
    // Encontra o item gold real que foi sorteado
    const goldWinner = winners.find(w => w.item._wasGoldPlaceholder);
    const realItem = goldWinner ? goldWinner.item : goldItems[Math.floor(Math.random() * goldItems.length)];
    
    // Gerar track da segunda roleta com APENAS itens gold
    const gWinnerIdx = 40 + Math.floor(Math.random() * 10);
    const gTrack = [];
    for (let i = 0; i < 60; i++) {
        if (i === gWinnerIdx) {
            gTrack.push({ id: i, item: realItem, rData: rarities['gold'] });
        } else {
            const randomGold = goldItems[Math.floor(Math.random() * goldItems.length)];
            gTrack.push({ id: i, item: randomGold, rData: rarities['gold'] });
        }
    }
    
    setGoldTrack(gTrack);
    setGoldWinnerIndex(gWinnerIdx);
    setGoldOffset(0);
    setGoldSpinPhase(true);
    setGoldSpinning(false);
    
    // Play epic crate open sound
    if (!muted) {
        try {
            const audio = new Audio('/sounds/csgo_ui_crate_open.wav');
            audio.volume = 0.7;
            audio.play();
        } catch(e) {}
    }
    
    // Start gold roulette spin after UI renders
    setTimeout(() => {
        setGoldSpinning(true);
        const targetX = (gWinnerIdx * ITEM_SIZE) + (Math.floor(Math.random() * 80) - 40);
        setGoldOffset(-targetX);
        
        // Gold tick sound tracking
        let currentGoldIndex = 0;
        const checkGoldPosition = () => {
            const el = goldContainerRef.current;
            if (!el) return;
            const style = window.getComputedStyle(el);
            let currentX = 0;
            const match3d = style.transform.match(/matrix3d\((.+)\)/);
            if (match3d) {
                const values = match3d[1].split(', ');
                currentX = Math.abs(parseFloat(values[12]));
            } else {
                const match2d = style.transform.match(/matrix\((.+)\)/);
                if (match2d) {
                    const values = match2d[1].split(', ');
                    currentX = Math.abs(parseFloat(values[4]));
                }
            }

            const index = Math.floor((currentX + (ITEM_SIZE/2)) / ITEM_SIZE);
            if (index > currentGoldIndex) {
                currentGoldIndex = index;
                playTick();
            }
            if (el.dataset.spinning === 'true') {
                requestAnimationFrame(checkGoldPosition);
            }
        };
        if (goldContainerRef.current) {
            goldContainerRef.current.dataset.spinning = 'true';
            requestAnimationFrame(checkGoldPosition);
        }
    }, 100);
  };

  const handleGoldSpinEnd = (e) => {
    if (e && e.target !== goldContainerRef.current) return;
    if (e && e.propertyName !== 'transform') return;
    if (!goldSpinning) return;
    
    setGoldSpinning(false);
    if (goldContainerRef.current) goldContainerRef.current.dataset.spinning = 'false';
    
    // Substituir o placeholder nos pendingWinners pelo item real da gold track
    const realGoldItem = goldTrack[goldWinnerIndex];
    const updatedWinners = pendingWinners.map(w => {
        if (w.item._wasGoldPlaceholder && realGoldItem) {
            return { ...w, item: { ...realGoldItem.item, _wasGoldPlaceholder: false }, rData: rarities['gold'] };
        }
        return w;
    });
    
    // Fechamos a gold phase e mostramos o resultado final
    setTimeout(() => {
        setGoldSpinPhase(false);
        finalizeResults(updatedWinners);
    }, 300);
  };

  const finalizeResults = (winners) => {
    setResults(winners);
    setShowPopup(true);
    
    const bestRarity = winners.some(w => w.item.rarity === 'gold') ? 'gold' : 
                       winners.some(w => w.item.rarity === 'covert') ? 'covert' : 
                       winners.some(w => w.item.rarity === 'classified') ? 'classified' : 
                       winners.some(w => w.item.rarity === 'restricted') ? 'restricted' : 'milspec';

    playWinSound(bestRarity);

    if (bestRarity === 'covert' || bestRarity === 'gold') {
      confetti({ particleCount: 400, spread: 160, origin: { y: 0.6 }, zIndex: 9999 });
    } else if (bestRarity === 'classified') {
      confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 }, zIndex: 9999 });
    }

    try {
      const inv = JSON.parse(localStorage.getItem('dopashop_inventory')) || [];
      winners.forEach(winner => {
          const itemPayload = {
              id: winner.item.id,
              name: winner.item.name,
              icon: winner.item.icon,
              image: winner.item.image,
              price: winner.item.price,
              rarity: winner.item.rarity,
              colorText: winner.rData.color,
              bgGradient: winner.rData.bg,
              colorBorder: winner.rData.border
          };
          const existing = inv.find(i => i.id === itemPayload.id);
          if (existing) {
            existing.count += 1;
          } else {
            inv.push({ ...itemPayload, count: 1 });
          }
      });
      localStorage.setItem('dopashop_inventory', JSON.stringify(inv));
    } catch(e) {}
  };

  const toggleFavoriteCase = (caseId) => {
    setFavoriteCases(prev => {
      const next = prev.includes(caseId) ? prev.filter(id => id !== caseId) : [...prev, caseId];
      localStorage.setItem('dopashop_fav_cases', JSON.stringify(next));
      return next;
    });
  };

  return (
    <div className="flex flex-col items-center font-sans bg-transparent relative overflow-hidden pb-12 w-[100vw] -ml-[50vw] left-1/2 md:w-full md:max-w-6xl md:ml-0 md:left-auto md:rounded-2xl">
      
      {/* HEADER TABS - CLEAN & ELEGANT */}
      <div className="w-full border-b border-white/5 px-4 md:px-8 py-5 flex flex-col md:flex-row items-center justify-between z-10 mb-6 bg-transparent gap-4 relative">
        <div className="flex items-center gap-4 relative z-10">
            <h2 className="text-xl font-medium text-zinc-200 tracking-wide flex items-center gap-2">
                CAIXAS CS
            </h2>
        </div>
        
        <div className="flex flex-col md:flex-row items-center gap-4 relative z-10">
            {/* Balances container */}
            <div className="flex bg-zinc-900/50 rounded-2xl p-1.5 border border-white/5 backdrop-blur-sm gap-1">
              <div className="py-1.5 px-3 rounded-xl flex items-center gap-3">
                <span className="text-accent font-bold text-[10px] bg-accent/10 px-2 py-0.5 rounded-md uppercase">PIX</span>
                <div className="text-sm font-semibold text-zinc-100">R$ {pixBalance.toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
              </div>
              <div className="w-[1px] bg-white/5 my-2"></div>
              <div className="py-1.5 px-3 rounded-xl flex items-center gap-3">
                <span className="text-zinc-400 font-bold text-[10px] bg-white/5 px-2 py-0.5 rounded-md uppercase">COFRE</span>
                <div className="text-sm font-semibold text-zinc-100">R$ {inventory.reduce((sum, item) => sum + (item.price * item.count), 0).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex bg-[#121212] p-1 rounded-xl border border-white/5">
                <button 
                    onClick={() => { setTab('cases'); playClickSound(); }}
                    onMouseEnter={playHoverSound}
                    className={`px-6 py-2 rounded-lg text-xs font-semibold transition-all duration-300 ${tab === 'cases' ? 'bg-accent/10 text-accent shadow-sm border border-accent/20' : 'text-zinc-500 hover:text-accent border border-transparent'}`}
                >
                    Abrir Caixas
                </button>
                <button 
                    onClick={() => { setTab('inventory'); playClickSound(); }}
                    onMouseEnter={playHoverSound}
                    className={`px-6 py-2 rounded-lg text-xs font-semibold transition-all duration-300 flex items-center gap-2 ${tab === 'inventory' ? 'bg-accent/10 text-accent shadow-sm border border-accent/20' : 'text-zinc-500 hover:text-accent border border-transparent'}`}
                >
                    Meu Cofre
                    <span className={`px-2 py-0.5 rounded-full text-[9px] ${tab === 'inventory' ? 'bg-accent text-white' : 'bg-white/5 text-zinc-400'}`}>
                        {inventory.reduce((a, b) => a + (b.count || 1), 0)}
                    </span>
                </button>
            </div>
        </div>
      </div>

      {/* --- INVENTORY TAB --- */}
      {tab === 'inventory' && (
        <div className="w-full px-4 md:px-8 min-h-[500px]">
           {/* INVENTORY SUMMARY & ACTIONS */}
           <div className="flex flex-col md:flex-row justify-between items-center bg-[#121212] px-6 py-4 rounded-2xl border border-white/5 mb-8 gap-4">
              <div className="flex items-center gap-4">
                 <div className="h-10 w-10 bg-[#1a1a1a] rounded-xl flex items-center justify-center border border-white/5">
                    <span className="text-lg opacity-80">💼</span>
                 </div>
                 <div>
                    <h3 className="text-zinc-500 text-[10px] font-semibold uppercase tracking-wider mb-0.5">Valor do Cofre</h3>
                    <p className="text-xl font-bold text-zinc-100">
                       R$ {inventory.reduce((sum, item) => sum + (item.price * item.count), 0).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                    </p>
                 </div>
              </div>
              <button 
                 onClick={sellAllItems}
                 disabled={inventory.length === 0}
                 className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2.5 rounded-xl text-xs font-semibold transition-all disabled:opacity-30 disabled:cursor-not-allowed"
              >
                 Vender Tudo
              </button>
           </div>
           
           {inventory.length === 0 ? (
               <div className="flex flex-col items-center justify-center py-24 border border-dashed border-white/5 rounded-3xl bg-[#111] mt-4">
                   <div className="h-16 w-16 bg-[#161616] rounded-full flex items-center justify-center mb-4">
                      <span className="text-2xl opacity-40">🎒</span>
                   </div>
                   <h3 className="text-lg font-medium text-zinc-300">O Cofre está vazio</h3>
                   <p className="text-zinc-600 text-sm mt-1">Abra caixas para colecionar skins.</p>
               </div>
           ) : (
               <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5 animate-fade-in-up">
                   {inventory.map((item, idx) => {
                       const rData = rarities[item.rarity] || rarities['milspec'];
                       return (
                           <div key={`${item.id}-${idx}`} className="bg-[#121212] aspect-[4/5] rounded-xl overflow-hidden flex flex-col items-center justify-between relative border border-white/5 group p-3 transition-colors hover:bg-[#161616]">
                               {/* Indicador de Raridade minimalista */}
                               <div className="absolute top-3 left-3 w-1.5 h-1.5 rounded-full" style={{ backgroundColor: rData.hex }}></div>
                               
                               <div className="absolute top-2 right-2 bg-[#1a1a1a] text-zinc-300 text-[10px] px-2 py-0.5 rounded-md border border-white/5 z-30 font-medium">
                                  x{item.count}
                               </div>

                               <div className="flex-1 w-full flex items-center justify-center relative z-10 mt-4 mb-2">
                                   {item.image ? (
                                       <img src={item.image} alt={item.name} className="max-h-full max-w-full object-contain drop-shadow-md group-hover:scale-105 transition-transform duration-300" />
                                   ) : item.icon && !item.icon.includes('http') ? (
                                       <span className="text-5xl opacity-80 group-hover:scale-105 transition-transform duration-300">{item.icon}</span>
                                   ) : (
                                       <span className="text-5xl opacity-80 group-hover:scale-105 transition-transform duration-300">🔫</span>
                                   )}
                               </div>

                               <div className="w-full text-center relative z-10 pt-2 pb-1 bg-[#0f0f0f] rounded-lg mt-1 border border-white/5">
                                   <p className={`text-[10px] font-semibold truncate px-1 text-zinc-300`}>{item.name.split('|')[1] || item.name}</p>
                                   <p className="text-[10px] text-zinc-500 mt-1">R$ {item.price.toFixed(2)}</p>
                               </div>

                               <div className="absolute inset-0 bg-[#0d0d0d]/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-40 rounded-xl">
                                   <button 
                                      onClick={() => sellInventoryItem(item)}
                                      className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-5 py-2 rounded-lg transition-colors"
                                   >
                                       Vender
                                   </button>
                               </div>
                           </div>
                       );
                   })}
               </div>
           )}
        </div>
      )}

      {/* --- VIEW: SELECTOR --- */}
      {tab === 'cases' && view === 'selector' && (
        <div className="w-full px-4 md:px-8">
          <div className="mb-8 flex justify-center">
             <div className="relative w-full max-w-lg">
               <input 
                  type="text" 
                  placeholder="Pesquisar caixa..." 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-zinc-900/50 border border-white/10 text-white text-sm rounded-2xl pl-12 pr-4 py-4 focus:outline-none focus:border-accent/50 focus:ring-1 focus:ring-accent/50 shadow-inner transition-colors backdrop-blur-sm"
               />
               <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl opacity-50">🔍</span>
             </div>
          </div>

          {loadingCases ? (
              <div className="flex flex-col items-center justify-center py-32">
                  <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin"></div>
                  <p className="mt-6 text-zinc-400 font-bold">Carregando Mercado da Steam...</p>
              </div>
          ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-5 animate-fade-in-up pb-8 max-h-[700px] overflow-y-auto no-scrollbar">
                  {casesData.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).map(c => (
                  <div 
                      key={c.id} 
                      onClick={() => handleSelectCase(c)}
                      onMouseEnter={playHoverSound}
                      className="flex flex-col items-center cursor-pointer group bg-transparent border border-white/10 rounded-xl hover:border-accent/40 hover:bg-accent/5 transition-all relative overflow-hidden pt-5 shadow-sm hover:shadow-[0_0_15px_rgba(232,93,58,0.15)] h-full"
                  >
                      {/* Top Name (Fixed height for alignment) */}
                      <div className="h-10 flex items-center justify-center w-full px-2 mb-2">
                          <h3 className="text-xs md:text-sm font-medium text-zinc-200 text-center line-clamp-2 group-hover:text-accent transition-colors">{c.name}</h3>
                      </div>
                      
                      {/* Image */}
                      <div className="h-24 md:h-32 w-full flex items-center justify-center p-2 mb-2 relative mt-auto">
                         <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 rounded-full blur-[25px] transition-opacity"></div>
                         <img src={c.image} alt={c.name} className="max-h-full object-contain group-hover:scale-110 transition-transform filter drop-shadow-[0_10px_15px_rgba(0,0,0,0.6)] relative z-10" />
                      </div>
                      
                      {/* Bottom Price Tag (Trapezoid - Themed) */}
                      <div className="w-full flex justify-center mt-auto">
                          <div 
                             className="w-[85%] h-8 bg-accent/80 flex items-center justify-center text-[11px] md:text-xs font-semibold text-white transition-colors group-hover:bg-accent"
                             style={{ clipPath: 'polygon(15px 0, calc(100% - 15px) 0, 100% 100%, 0 100%)' }}
                          >
                              R$ {c.price.toFixed(2)}
                          </div>
                      </div>
                  </div>
                  ))}
              </div>
          )}
        </div>
      )}

      {/* --- VIEW: OPENER --- */}
      {tab === 'cases' && view === 'opener' && activeCase && (
        <div className="w-full flex flex-col items-center animate-fade-in-up px-0">
          
          {/* PREMIUM FLOATING HEADER */}
          <div className="w-full flex justify-between items-center px-4 py-3 bg-[#0a0a0a]/80 backdrop-blur-md border-b border-white/5 sticky top-0 z-40">
             <button onClick={() => { setView('selector'); playClickSound(); }} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors text-[11px] font-bold uppercase tracking-wider py-2 touch-manipulation">
                <ArrowLeft className="w-4 h-4" /> Voltar
             </button>
             <div className="flex flex-col items-end">
                <h2 className="text-sm md:text-lg font-black text-white uppercase tracking-wider">{activeCase.name}</h2>
                <span className="text-emerald-400 text-[10px] font-bold">R$ {activeCase.price.toFixed(2)}</span>
             </div>
          </div>

          {/* ROULETTE TRACKS */}
          <div className={`w-full max-w-5xl mx-auto rounded-2xl bg-[#0a0c10]/80 border border-white/5 shadow-inner overflow-hidden relative mt-6 ${openCount > 1 ? 'flex flex-row justify-center' : 'flex flex-col'}`} style={{ height: openCount > 1 ? '400px' : '220px' }}>
             
             {/* Dynamic Center Indicator & Edge Fades */}
             {openCount === 1 ? (
                 <>
                     {/* Horizontal Lines (The sleek center accent) */}
                     <div className="absolute top-0 bottom-0 left-1/2 w-[2px] -ml-[1px] bg-accent z-30 shadow-[0_0_20px_rgba(232,93,58,0.8)] pointer-events-none" />
                     {/* Top and Bottom glowing triangles */}
                     <div className="absolute top-0 left-1/2 -translate-x-1/2 z-30 pointer-events-none drop-shadow-[0_5px_5px_rgba(232,93,58,0.8)]"><div className="w-0 h-0 border-l-[8px] border-r-[8px] border-t-[10px] border-l-transparent border-r-transparent border-t-accent" /></div>
                     <div className="absolute bottom-0 left-1/2 -translate-x-1/2 z-30 pointer-events-none drop-shadow-[0_-5px_5px_rgba(232,93,58,0.8)]"><div className="w-0 h-0 border-l-[8px] border-r-[8px] border-b-[10px] border-l-transparent border-r-transparent border-b-accent" /></div>
                     
                     {/* Horizontal Fades (Softer and deeper) */}
                     <div className="absolute inset-y-0 left-0 w-24 md:w-48 bg-gradient-to-r from-[#0a0c10] via-[#0a0c10]/80 to-transparent z-20 pointer-events-none" />
                     <div className="absolute inset-y-0 right-0 w-24 md:w-48 bg-gradient-to-l from-[#0a0c10] via-[#0a0c10]/80 to-transparent z-20 pointer-events-none" />
                 </>
             ) : (
                 <>
                     {/* Vertical Lines */}
                     <div className="absolute left-0 right-0 top-1/2 h-[2px] -mt-[1px] bg-accent z-30 shadow-[0_0_20px_rgba(232,93,58,0.8)] pointer-events-none" />
                     <div className="absolute left-0 top-1/2 -translate-y-1/2 z-30 pointer-events-none drop-shadow-[5px_0_5px_rgba(232,93,58,0.8)]"><div className="w-0 h-0 border-t-[8px] border-b-[8px] border-l-[10px] border-t-transparent border-b-transparent border-l-accent" /></div>
                     <div className="absolute right-0 top-1/2 -translate-y-1/2 z-30 pointer-events-none drop-shadow-[-5px_0_5px_rgba(232,93,58,0.8)]"><div className="w-0 h-0 border-t-[8px] border-b-[8px] border-r-[10px] border-t-transparent border-b-transparent border-r-accent" /></div>
                     
                     {/* Vertical Fades */}
                     <div className="absolute inset-x-0 top-0 h-32 md:h-48 bg-gradient-to-b from-[#0a0c10] via-[#0a0c10]/80 to-transparent z-20 pointer-events-none" />
                     <div className="absolute inset-x-0 bottom-0 h-32 md:h-48 bg-gradient-to-t from-[#0a0c10] via-[#0a0c10]/80 to-transparent z-20 pointer-events-none" />
                 </>
             )}
             
             {tracks.map((trackArr, trackIdx) => (
                 <div key={trackIdx} className="relative shrink-0 overflow-hidden" style={openCount === 1 ? { width: '100%', height: '100%' } : { height: '100%', width: `${100/openCount}%` }}>
                     <div 
                        ref={el => containerRefs.current[trackIdx] = el} 
                        onTransitionEnd={trackIdx === 0 ? handleSpinEnd : null} 
                        className={`absolute top-0 bottom-0 left-0 right-0 flex ${openCount > 1 ? 'flex-col items-center justify-start' : 'flex-row items-center justify-start'} w-full h-full`} 
                        style={{ 
                            transform: openCount > 1 ? `translate3d(0, ${offsets[trackIdx]}px, 0)` : `translate3d(${offsets[trackIdx]}px, 0, 0)`, 
                            transition: spinning ? 'transform 6.5s cubic-bezier(0.15, 0.85, 0.15, 1)' : 'none', 
                            paddingLeft: openCount === 1 ? `calc(50% - ${ITEM_SIZE/2}px)` : 0,
                            paddingTop: openCount > 1 ? `calc(50% - ${ITEM_SIZE/2}px)` : 0, 
                            willChange: 'transform' 
                        }}
                     >
                        {trackArr.map((t, i) => {
                          const parts = t.item.name.split('|');
                          const skinName = parts[1]?.trim();
                          const weaponName = parts[0]?.trim();
                          return (
                            <div key={`${t.id}-${i}`} className={`shrink-0 flex flex-col items-center justify-center relative bg-gradient-to-b from-[#1b1e24] to-[#0f1115] border border-white/[0.02] rounded-md overflow-hidden shadow-md ${openCount > 1 ? 'w-[92%] h-[150px] my-[2px]' : 'w-[160px] h-[85%] mx-[2px]'}`}>
                                {/* Classic CS Rarity Bottom Line */}
                                <div className="absolute bottom-0 left-0 right-0 h-[4px]" style={{ backgroundColor: t.rData.hex, boxShadow: `0 0 10px ${t.rData.hex}` }}></div>
                                
                                <div className={`relative w-full flex-1 flex items-center justify-center ${openCount > 1 ? 'mt-2' : 'mt-4'}`}>
                                  {/* Background Glow instead of Hexagon */}
                                  {!t.item.isPlaceholder && <div className="absolute inset-0 opacity-20 blur-[20px]" style={{ backgroundColor: t.rData.hex }}></div>}
                                  
                                  {t.item.image ? (
                                      <img src={t.item.image} alt={t.item.name} className={`relative z-10 w-[85%] max-w-[85%] object-contain ${spinning ? '' : 'drop-shadow-[0_15px_15px_rgba(0,0,0,0.8)] scale-110 transition-transform duration-500'}`} />
                                  ) : (
                                      <span className="relative z-10 text-3xl md:text-5xl drop-shadow-xl">{t.item.icon}</span>
                                  )}
                                </div>
                                
                                {t.item.isPlaceholder ? (
                                    <span className="text-[12px] md:text-[13px] font-black truncate w-full text-center px-2 pb-4 text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">{t.item.name}</span>
                                ) : (
                                    <div className="w-full flex flex-col items-center pb-3 px-2 z-10">
                                        <span className="text-[11px] md:text-[12px] font-bold truncate w-full text-center text-white">{weaponName}</span>
                                        <span className="text-[9px] md:text-[10px] font-medium truncate w-full text-center mt-0.5" style={{ color: t.rData.hex }}>{skinName || '★'}</span>
                                    </div>
                                )}
                            </div>
                          )
                        })}
                     </div>
                 </div>
             ))}
          </div>

          {/* PREMIUM ACTION BLOCK */}
          <div className="w-full px-4 mt-8 mb-12 flex flex-col items-center">
             <div className="w-full max-w-md bg-[#111] p-5 rounded-3xl border border-white/5 shadow-[0_10px_40px_rgba(0,0,0,0.8)] relative overflow-hidden">
                 {/* Background Glow */}
                 <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-48 h-48 bg-accent/20 blur-[60px] rounded-full pointer-events-none"></div>
                 
                 {/* Hexagon controls */}
                 <div className="flex justify-between items-center mb-6 w-full relative z-10 px-2">
                    {/* Placeholder to keep center items aligned */}
                    <div className="w-[48px] h-[48px] md:w-10 md:h-10"></div>
                    <div className="flex gap-2">
                      {[1, 2, 3].map(n => (
                        <HexButton key={n} active={openCount === n} onClick={() => setOpenCount(n)} title={`Abrir ${n} caixa${n > 1 ? 's' : ''}`}>
                          <span className={`text-[15px] font-black ${openCount === n ? 'text-white' : 'text-zinc-500'}`}>{n}</span>
                        </HexButton>
                      ))}
                    </div>
                    <HexButton active={!muted} onClick={() => setMuted(prev => !prev)} title={muted ? 'Ativar som' : 'Mutar som'}>
                        {muted ? <VolumeX className="w-5 h-5 md:w-4 md:h-4 text-red-500" /> : <Volume2 className="w-5 h-5 md:w-4 md:h-4 text-white" />}
                    </HexButton>
                 </div>
                 
                 {/* The Main Button */}
                 <div className="relative w-full">
                     <button 
                          onClick={openCase}
                          onMouseEnter={playHoverSound}
                          disabled={pixBalance < (activeCase.price * openCount)}
                          className={`w-full py-4 rounded-2xl text-sm md:text-base font-black uppercase tracking-widest relative z-10 overflow-hidden transition-all shadow-[0_0_20px_rgba(136,71,255,0.25)] ${
                              pixBalance < (activeCase.price * openCount)
                              ? 'bg-zinc-800 text-zinc-500 border border-white/5 shadow-none'
                              : 'bg-accent text-white hover:bg-accent/90 active:scale-[0.98]'
                          }`}
                     >
                          <span className="relative z-10">
                              {pixBalance < (activeCase.price * openCount) ? 'Saldo Insuficiente' : `Abrir por R$ ${(activeCase.price * openCount).toFixed(2)}`}
                          </span>
                     </button>
                 </div>
             </div>
          </div>

          {/* CONTENTS GRID */}
          <div className="w-full max-w-6xl flex flex-col mt-4 px-2 mb-16">
            <h3 className="text-[18px] md:text-2xl font-black text-white mb-8 md:text-center tracking-wide">Conteúdo da caixa</h3>
            
            <div className="flex flex-wrap justify-center gap-4 md:gap-5 pb-6">
               {(() => {
                 const nonGolds = activeCase.items.filter(i => i.rarity !== 'gold');
                 const hasGold = activeCase.items.some(i => i.rarity === 'gold');
                 const displayItems = hasGold ? [...nonGolds, GOLD_PLACEHOLDER] : nonGolds;
                 
                 return displayItems.sort((a, b) => {
                   const rarityWeight = { gold: 5, covert: 4, classified: 3, restricted: 2, milspec: 1 };
                   const weightDiff = (rarityWeight[b.rarity] || 0) - (rarityWeight[a.rarity] || 0);
                   return weightDiff !== 0 ? weightDiff : b.price - a.price;
                 }).map((item, idx) => {
                   const rData = rarities[item.rarity];
                   const isGold = item.rarity === 'gold';
                   
                   // Real CS:GO odds mapping
                   const CSGO_BASE_ODDS = {
                     milspec: 79.923,
                     restricted: 15.985,
                     classified: 3.197,
                     covert: 0.639,
                     gold: 0.256
                   };
                   
                   // For gold, it's the combined probability. For others, it's divided by count.
                   let realProb = CSGO_BASE_ODDS[item.rarity];
                   if (!isGold) {
                       const countInRarity = activeCase.items.filter(i => i.rarity === item.rarity).length || 1;
                       realProb = realProb / countInRarity;
                   }

                   const nameParts = item.name.split('|');
                   const weaponName = nameParts[0]?.trim();
                   const skinName = nameParts[1]?.trim();

                   return (
                     <div 
                        key={`${item.id}-${idx}`}
                        onMouseEnter={playHoverSound}
                        className="w-[145px] md:w-[170px] aspect-[3/4.1] rounded-2xl overflow-hidden flex flex-col items-center relative border border-white/[0.04] bg-[#0f131a]/80 backdrop-blur-md group hover:bg-[#141924] hover:border-white/10 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-2xl hover:-translate-y-1"
                     >
                       {/* Sleek Top Rarity Line */}
                       <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-[3px] rounded-b-md z-20 transition-all duration-500 group-hover:w-20" style={{ backgroundColor: rData.hex, boxShadow: `0 2px 10px ${rData.hex}` }}></div>
                       
                       {/* Info Icon */}
                       <div className="absolute top-3 left-3 w-5 h-5 rounded-full bg-white/5 flex items-center justify-center text-[9px] text-zinc-400 font-black z-30 transition-colors group-hover:bg-white/10 group-hover:text-white">i</div>
                       
                       {/* Percentage */}
                       <div className="absolute top-3 right-3 text-[10px] text-zinc-400 font-bold z-30 tracking-wider">{realProb.toFixed(3)}%</div>

                       {/* Image Area with Hexagon Glow */}
                       <div className="flex-1 w-full flex items-center justify-center relative z-10 mt-8 mb-2">
                          {isGold ? (
                              <img src="/rare_special.png" alt="Rare Special Item" className="w-[85%] max-h-full object-contain relative z-10 drop-shadow-[0_10px_20px_rgba(250,204,21,0.3)] group-hover:scale-110 transition-transform duration-500" />
                          ) : (
                              <>
                                  <HexagonBg color={rData.hex} glow={true} />
                                  {item.image ? (
                                      <img src={item.image} alt={item.name} className="w-[90%] max-h-full object-contain relative z-10 drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)] group-hover:scale-110 group-hover:-translate-y-1 transition-all duration-500" />
                                  ) : (
                                      <span className="text-4xl relative z-10 drop-shadow-xl group-hover:scale-110 transition-transform duration-500">{item.icon}</span>
                                  )}
                              </>
                          )}
                       </div>

                       {/* Split Item Name (Weapon | Skin) */}
                       <div className="w-full flex flex-col items-center justify-end relative z-10 pb-4 px-2 h-14">
                         {isGold ? (
                            <p className="text-[11px] md:text-[13px] font-black text-white truncate drop-shadow-md tracking-wide">★ Rare Special Item ★</p>
                         ) : (
                            <>
                               <p className="text-[11px] md:text-[13px] font-bold text-white truncate drop-shadow-md w-full text-center">{weaponName}</p>
                               {skinName && (
                                   <p className="text-[10px] md:text-[11px] font-medium text-zinc-400 truncate w-full text-center mt-0.5 group-hover:text-zinc-300 transition-colors">{skinName}</p>
                               )}
                            </>
                         )}
                       </div>
                     </div>
                   )
                 });
               })()}
            </div>
          </div>

          {/* COMPACT MODAL WINNER POPUP */}
          {showPopup && results.length > 0 && (
              <div className="fixed inset-0 z-[100] flex items-start justify-center pt-24 md:pt-32 p-4">
                  <style>{`
                    @keyframes popup-zoom {
                      0% { transform: scale(0.7); opacity: 0; filter: drop-shadow(0 0 0 rgba(0,0,0,0)); }
                      70% { transform: scale(1.03); opacity: 1; }
                      100% { transform: scale(1); opacity: 1; filter: drop-shadow(0 25px 25px rgba(0,0,0,0.5)); }
                    }
                    .animate-popup-zoom {
                      animation: popup-zoom 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) forwards;
                    }
                  `}</style>
                  <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setShowPopup(false)}></div>
                  
                  <div className="w-full flex flex-col items-center justify-center relative z-10 animate-popup-zoom mt-8 md:mt-0">
                      <div className={`flex flex-row justify-center items-center ${results.length > 1 ? 'gap-2 md:gap-8' : 'gap-8'} w-full max-w-4xl px-2`}>
                          {results.map((res, idx) => {
                              const isMulti = results.length > 1;
                              return (
                              <div key={idx} className={`flex flex-col items-center ${isMulti ? 'w-1/3 max-w-[150px]' : 'w-full'}`}>
                                  {/* Floating Image Area */}
                                  <div className={`${isMulti ? 'h-20 md:h-32' : 'h-32 md:h-40'} flex items-center justify-center mb-2 md:mb-4 relative w-full`}>
                                      <div className={`absolute inset-0 opacity-20 blur-[40px] rounded-full ${isMulti ? 'scale-100' : 'scale-150'}`} style={{ backgroundColor: res.rData.hex }}></div>
                                      {res.item.image ? (
                                          <img src={res.item.image} alt={res.item.name} className={`max-h-full max-w-full object-contain drop-shadow-[0_20px_25px_rgba(0,0,0,0.9)] relative z-10 ${isMulti ? 'scale-110' : 'scale-125'}`} />
                                      ) : (
                                          <span className={`${isMulti ? 'text-3xl' : 'text-5xl'} relative z-10 drop-shadow-2xl`}>{res.item.icon}</span>
                                      )}
                                  </div>
                                  
                                  {/* Typography */}
                                  <h2 className={`${isMulti ? 'text-[11px] md:text-xl leading-tight' : 'text-2xl md:text-3xl'} font-black uppercase text-white truncate text-center mt-2 drop-shadow-md w-full`}>
                                      {res.item.name.split('|')[1] ? res.item.name.split('|')[1].trim() : res.item.name}
                                  </h2>
                                  <p className={`${isMulti ? 'text-[8px] md:text-[10px]' : 'text-[10px] md:text-[11px]'} font-bold mt-1 uppercase tracking-[0.2em] w-full text-center truncate`} style={{ color: res.rData.hex }}>
                                      {res.item.name.split('|')[0].trim()}
                                  </p>
                              </div>
                              )
                          })}
                      </div>

                      {/* Minimalist Floating Actions */}
                      <div className="flex items-center justify-center gap-3 mt-8">
                          <button 
                            onClick={sellItemNow}
                            className="bg-[#0f9f59] hover:bg-[#12b365] text-white px-6 py-2.5 rounded-full font-bold uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(15,159,89,0.2)] flex items-center gap-2 border border-[#0f9f59]/50"
                          >
                            <span className="text-[11px]">Vender</span>
                            <span className="text-[11px] font-black opacity-90">R$ {results.reduce((a,b)=>a+b.item.price,0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                          </button>
                          <button 
                            onClick={() => { playAcceptSound(); setShowPopup(false); }}
                            className="bg-transparent hover:bg-white/10 text-white px-6 py-2.5 rounded-full font-bold text-[11px] uppercase tracking-wider transition-all border border-white/20 backdrop-blur-sm"
                          >
                            Manter
                          </button>
                      </div>
                  </div>
              </div>
          )}

        </div>
      )}

    </div>
  );
}
