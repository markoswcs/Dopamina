import React from "react";
import { ShoppingCart, Star, Heart } from "lucide-react";

export default function ProductCard({ product, onAddToCart, onBuyNow, onToggleFavorite, isFavorited }) {
  const fmt = (v) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  const discount = product.oldPrice ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) : 0;

  return (
    <div 
      className="group relative h-full"
      style={{ perspective: "800px" }}
    >
      <div 
        className="theme-card border theme-border rounded-2xl overflow-hidden flex flex-col h-full transition-all duration-500 ease-out group-hover:shadow-[0_20px_40px_-12px_rgba(0,0,0,0.2)] dark:group-hover:shadow-[0_20px_40px_-12px_rgba(0,0,0,0.5)] group-hover:-translate-y-1.5 group-hover:border-accent/40"
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Image */}
        <div className="relative w-full aspect-square bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 overflow-hidden">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
          />

          {/* Tag */}
          {product.tag && (
            <span className="absolute top-2 left-2 bg-accent/90 backdrop-blur-sm text-white px-2 py-0.5 rounded-md text-[8px] md:text-[9px] font-bold uppercase tracking-wider">
              {product.tag}
            </span>
          )}

          {/* Favorite */}
          <button 
            onClick={(e) => onToggleFavorite(product.id, e)}
            className="absolute top-2 right-2 p-1.5 rounded-full bg-white/70 dark:bg-black/40 backdrop-blur-sm hover:scale-110 transition-transform cursor-pointer"
          >
            <Heart className={`w-3.5 h-3.5 ${isFavorited ? 'fill-accent text-accent' : 'text-gray-500 dark:text-gray-400'}`} />
          </button>

          {/* Discount badge */}
          {discount > 0 && (
            <span className="absolute bottom-2 left-2 bg-emerald-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-md">
              -{discount}%
            </span>
          )}
        </div>

        {/* Content — compact */}
        <div className="p-3 flex flex-col flex-1">
          
          {/* Rating inline */}
          <div className="flex items-center gap-1 mb-1">
            <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
            <span className="text-[10px] font-semibold theme-text">{product.rating}</span>
            <span className="text-[10px] theme-muted">({product.salesCount})</span>
          </div>

          {/* Title */}
          <h3 className="font-display font-semibold text-xs md:text-[13px] theme-text leading-snug line-clamp-2 mb-2 flex-1">
            {product.name}
          </h3>

          {/* Price */}
          <div className="mb-3">
            {product.oldPrice && (
              <span className="line-through text-[10px] theme-muted block leading-none mb-0.5">
                {fmt(product.oldPrice)}
              </span>
            )}
            <span className="font-display font-extrabold text-base md:text-lg text-accent leading-none">
              {fmt(product.price)}
            </span>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1.5 mt-auto">
            <button 
              onClick={(e) => onBuyNow(product, e)}
              className="flex-1 py-2 bg-accent hover:bg-accent-dark text-white rounded-lg font-display font-bold text-[10px] uppercase tracking-wider shadow-md hover:shadow-lg hover:-translate-y-px transition-all active:scale-95 cursor-pointer"
            >
              Comprar
            </button>
            <button 
              onClick={(e) => onAddToCart(product, e)}
              className="p-2 bg-black/5 dark:bg-white/10 hover:bg-accent hover:text-white rounded-lg transition-all theme-text cursor-pointer active:scale-90"
              title="Adicionar ao Carrinho"
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
