import React from "react";
import { Home, Compass, ShoppingBag, Search, Map, User, Heart, Gamepad2 } from "lucide-react";

export default function BottomNav({ activeTab, setActiveTab, cartCount, onSearchClick }) {
  const tabs = [
    { id: "home", icon: Home, label: "Home", action: () => setActiveTab("home") },
    { id: "search", icon: Search, label: "Busca", action: onSearchClick },
    { id: "dopagames", icon: Gamepad2, label: "DopaGames", action: () => setActiveTab("dopagames") },
    { id: "support", icon: Heart, label: "Apoiar", action: () => setActiveTab("support") },
    { id: "cart", icon: ShoppingBag, label: "Cesta", badge: cartCount, action: () => setActiveTab("cart") },
    { id: "tracking", icon: Map, label: "Rastreio", action: () => setActiveTab("tracking") },
    { id: "profile", icon: User, label: "Perfil", action: () => setActiveTab("profile") }
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 theme-surface border-t theme-border shadow-[0_-4px_20px_rgba(0,0,0,0.05)] z-40 pb-safe">
      <div className="flex items-center justify-around px-1 py-2 overflow-x-auto gap-2 scrollbar-hide">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={(e) => {
                if (window.triggerDopaParticles) window.triggerDopaParticles(e.clientX, e.clientY);
                tab.action();
              }}
              className={`flex flex-col items-center justify-center w-14 h-12 relative transition-all cursor-pointer shrink-0 ${
                isActive ? "text-accent" : "theme-muted hover:theme-text"
              }`}
            >
              {isActive && (
                <div className="absolute -top-2 w-8 h-1 bg-accent rounded-b-full shadow-[0_2px_8px_rgba(232,93,58,0.5)]" />
              )}
              
              <div className={`relative transition-transform duration-300 ${isActive ? "-translate-y-1 scale-110" : ""}`}>
                <Icon className={`w-5 h-5 ${isActive ? (tab.id === 'favorites' ? 'fill-accent' : 'fill-accent/20') : ""}`} />
                {tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-danger text-white text-[8px] font-bold px-1.5 min-w-[14px] h-[14px] rounded-full flex items-center justify-center animate-bounce">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-[8px] font-semibold mt-1 transition-all ${isActive ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2 absolute"}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
